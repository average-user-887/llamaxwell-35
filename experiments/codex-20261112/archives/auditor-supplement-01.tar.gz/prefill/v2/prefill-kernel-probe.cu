#include "ggml/src/ggml-cuda/fattn-tile.cuh"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static constexpr int query_heads = 16;
static constexpr int key_value_heads = 2;

static void cuda_check(cudaError_t status) {
    if (status != cudaSuccess) {
        std::fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(status));
        std::exit(3);
    }
}

static float sample_value(uint32_t & state, float amplitude) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return amplitude * (float(state & 0xffffu) / 32768.0f - 1.0f);
}

template<int query_columns, int tune>
static void launch_probe(const float * queries, const half * keys, const half * values,
                         const half * mask, float * output, int query_count, int key_count) {
    const int block_threads = ggml_cuda_fattn_tile_get_nthreads(256, 256, query_columns * 8, 520, tune);
    const dim3 block(32, block_threads / 32);
    const dim3 grid((query_count + query_columns - 1) / query_columns, 1, key_value_heads);
    const uint3 fast_queries = init_fastdiv_values(query_count);
    const int query_stride = 256 * sizeof(float);
    const int query_head_stride = query_count * query_stride;
    const int key_stride = 256 * sizeof(half);
    const int key_head_stride = key_count * key_stride;
    const int mask_stride = key_count * sizeof(half);
    flash_attn_tile<256, 256, query_columns, 8, false, tune><<<grid, block>>>(
        reinterpret_cast<const char *>(queries), reinterpret_cast<const char *>(keys),
        reinterpret_cast<const char *>(values), reinterpret_cast<const char *>(mask),
        nullptr, nullptr, output, nullptr, 0.0625f, 0.0f, 0.0f, 0.0f, 0, 0.0f,
        256, fast_queries, query_heads, 1, query_stride, query_head_stride, query_heads * query_head_stride,
        256, key_count, key_value_heads, 1, key_stride, key_head_stride, int64_t(key_value_heads) * key_head_stride,
        key_stride, key_head_stride, int64_t(key_value_heads) * key_head_stride,
        query_count, 1, 1, mask_stride, query_count * mask_stride, int64_t(query_count) * mask_stride);
    cuda_check(cudaGetLastError());
}

static void launch_selected(int mode, const float * queries, const half * keys, const half * values,
                            const half * mask, float * output, int query_count, int key_count) {
    if (mode == 0) {
        launch_probe<4, 0>(queries, keys, values, mask, output, query_count, key_count);
    } else if (mode == 1) {
        launch_probe<2, 0>(queries, keys, values, mask, output, query_count, key_count);
    } else if (mode == 2) {
        launch_probe<2, 4>(queries, keys, values, mask, output, query_count, key_count);
    } else if (mode == 3) {
        launch_probe<4, 5>(queries, keys, values, mask, output, query_count, key_count);
    } else if (mode == 4) {
        launch_probe<4, 6>(queries, keys, values, mask, output, query_count, key_count);
    } else {
        launch_probe<4, 7>(queries, keys, values, mask, output, query_count, key_count);
    }
}

template<int query_columns, int tune>
static void print_resources(int mode) {
    cudaFuncAttributes attributes{};
    cuda_check(cudaFuncGetAttributes(&attributes, flash_attn_tile<256, 256, query_columns, 8, false, tune>));
    int active_blocks = 0;
    const int block_threads = ggml_cuda_fattn_tile_get_nthreads(256, 256, query_columns * 8, 520, tune);
    cuda_check(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
        &active_blocks, flash_attn_tile<256, 256, query_columns, 8, false, tune>, block_threads, 0));
    std::printf("{\"kind\":\"resources\",\"mode\":%d,\"threads_per_block\":%d,\"registers_per_thread\":%d,\"shared_bytes\":%zu,\"active_blocks_per_sm\":%d}\n",
                mode, block_threads, attributes.numRegs, attributes.sharedSizeBytes, active_blocks);
}

int main(int argc, char ** argv) {
    const int query_count = argc > 1 ? std::atoi(argv[1]) : 1024;
    const int key_count = argc > 2 ? std::atoi(argv[2]) : 98304;
    const int rounds = argc > 3 ? std::atoi(argv[3]) : 3;
    const int candidate_mode = argc > 4 ? std::atoi(argv[4]) : 3;
    if (argc > 5 || query_count < 4 || query_count > 1024 || query_count % 4 != 0 ||
        key_count < query_count || key_count > 131072 || key_count % 256 != 0 ||
        rounds < 1 || rounds > 8 || candidate_mode < 1 || candidate_mode > 5) {
        std::fprintf(stderr, "usage: prefill-kernel-probe [query_count:4..1024,multiple4] [key_count:256..131072,multiple256] [rounds:1..8] [candidate_mode:1..5]\n");
        return 2;
    }
    cudaDeviceProp device{};
    cuda_check(cudaGetDeviceProperties(&device, 0));
    if (device.major != 5 || device.minor != 2) {
        std::fprintf(stderr, "Probe is restricted to SM52; got SM%d%d\n", device.major, device.minor);
        return 2;
    }
    cuda_check(cudaSetDevice(0));
    const size_t query_elements = size_t(query_count) * query_heads * 256;
    const size_t key_elements = size_t(key_count) * key_value_heads * 256;
    const size_t mask_elements = size_t(query_count) * key_count;
    const size_t device_bytes = query_elements * sizeof(float) * 2 + key_elements * sizeof(half) * 2 + mask_elements * sizeof(half);
    std::printf("{\"kind\":\"shape\",\"query_count\":%d,\"key_count\":%d,\"query_heads\":%d,\"kv_heads\":%d,\"head_dim\":256,\"device_bytes\":%zu,\"rounds\":%d,\"candidate_mode\":%d}\n",
                query_count, key_count, query_heads, key_value_heads, device_bytes, rounds, candidate_mode);
    print_resources<4, 0>(0);
    print_resources<2, 0>(1);
    print_resources<2, 4>(2);
    print_resources<4, 5>(3);
    print_resources<4, 6>(4);
    print_resources<4, 7>(5);
    std::vector<float> host_queries(query_elements);
    std::vector<half> host_keys(key_elements), host_values(key_elements), host_mask(mask_elements);
    uint32_t random_state = 0x12345678u;
    for (float & element : host_queries) {
        element = sample_value(random_state, 2.0f);
    }
    for (size_t index = 0; index < key_elements; ++index) {
        host_keys[index] = __float2half(sample_value(random_state, 2.0f));
        host_values[index] = __float2half(sample_value(random_state, 1.0f));
    }
    for (int query_index = 0; query_index < query_count; ++query_index) {
        const int last_key = key_count - query_count + query_index;
        for (int key_index = 0; key_index < key_count; ++key_index) {
            host_mask[size_t(query_index) * key_count + key_index] =
                __float2half(key_index <= last_key ? 0.0f : -INFINITY);
        }
    }
    float * device_queries = nullptr;
    float * device_output = nullptr;
    half * device_keys = nullptr;
    half * device_values = nullptr;
    half * device_mask = nullptr;
    cuda_check(cudaMalloc(&device_queries, query_elements * sizeof(float)));
    cuda_check(cudaMalloc(&device_output, query_elements * sizeof(float)));
    cuda_check(cudaMalloc(&device_keys, key_elements * sizeof(half)));
    cuda_check(cudaMalloc(&device_values, key_elements * sizeof(half)));
    cuda_check(cudaMalloc(&device_mask, mask_elements * sizeof(half)));
    cuda_check(cudaMemcpy(device_queries, host_queries.data(), query_elements * sizeof(float), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_keys, host_keys.data(), key_elements * sizeof(half), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_values, host_values.data(), key_elements * sizeof(half), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_mask, host_mask.data(), mask_elements * sizeof(half), cudaMemcpyHostToDevice));
    std::vector<float> reference(query_elements), candidate(query_elements);
    launch_selected(0, device_queries, device_keys, device_values, device_mask, device_output, query_count, key_count);
    cuda_check(cudaMemcpy(reference.data(), device_output, query_elements * sizeof(float), cudaMemcpyDeviceToHost));
    launch_selected(candidate_mode, device_queries, device_keys, device_values, device_mask, device_output, query_count, key_count);
    cuda_check(cudaMemcpy(candidate.data(), device_output, query_elements * sizeof(float), cudaMemcpyDeviceToHost));
    size_t nonfinite_count = 0;
    size_t different_bits = 0;
    double maximum_absolute = 0.0;
    double maximum_scaled_relative = 0.0;
    double squared_error = 0.0;
    for (size_t index = 0; index < query_elements; ++index) {
        if (!std::isfinite(reference[index]) || !std::isfinite(candidate[index])) {
            ++nonfinite_count;
            continue;
        }
        different_bits += std::memcmp(&reference[index], &candidate[index], sizeof(float)) != 0;
        const double difference = std::abs(double(reference[index]) - candidate[index]);
        maximum_absolute = std::max(maximum_absolute, difference);
        maximum_scaled_relative = std::max(maximum_scaled_relative, difference / std::max(1e-5, std::abs(double(reference[index]))));
        squared_error += difference * difference;
    }
    const double root_mean_squared_error = std::sqrt(squared_error / query_elements);
    std::printf("{\"kind\":\"correctness\",\"elements\":%zu,\"different_bits\":%zu,\"nonfinite\":%zu,\"max_absolute\":%.12g,\"max_relative_floor1e5\":%.12g,\"rmse\":%.12g}\n",
                query_elements, different_bits, nonfinite_count, maximum_absolute, maximum_scaled_relative, root_mean_squared_error);
    if (nonfinite_count != 0 || maximum_absolute > 1e-4 || root_mean_squared_error > 1e-5) {
        std::fprintf(stderr, "Numerical comparison exceeds probe safety threshold; no performance run.\n");
        return 4;
    }
    cudaEvent_t start_event, stop_event;
    cuda_check(cudaEventCreate(&start_event));
    cuda_check(cudaEventCreate(&stop_event));
    const int order[] = {0, candidate_mode, candidate_mode, 0};
    for (int round = 0; round < rounds; ++round) {
        for (int position = 0; position < 4; ++position) {
            const int mode = order[position];
            cuda_check(cudaEventRecord(start_event));
            launch_selected(mode, device_queries, device_keys, device_values, device_mask, device_output, query_count, key_count);
            cuda_check(cudaEventRecord(stop_event));
            cuda_check(cudaEventSynchronize(stop_event));
            float milliseconds = 0.0f;
            cuda_check(cudaEventElapsedTime(&milliseconds, start_event, stop_event));
            std::printf("{\"kind\":\"timing\",\"round\":%d,\"position\":%d,\"mode\":%d,\"milliseconds\":%.6f}\n",
                        round, position, mode, milliseconds);
            std::fflush(stdout);
        }
    }
    cuda_check(cudaEventDestroy(start_event));
    cuda_check(cudaEventDestroy(stop_event));
    cuda_check(cudaFree(device_queries));
    cuda_check(cudaFree(device_output));
    cuda_check(cudaFree(device_keys));
    cuda_check(cudaFree(device_values));
    cuda_check(cudaFree(device_mask));
    return 0;
}
