#include "arg.h"
#include "common.h"

#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

static bool parse(common_params & params, std::vector<std::string> arguments) {
    std::vector<char *> pointers;
    for (auto & argument : arguments) {
        pointers.push_back(argument.data());
    }
    return common_params_parse(pointers.size(), pointers.data(), params, LLAMA_EXAMPLE_SERVER);
}

int main() {
    common_params params;
    assert(params.n_batch_mixed == 0);
    assert(parse(params, {"check-args", "--batch-size", "2048", "--ubatch-size", "1024", "--mixed-batch-size", "512"}));
    assert(params.n_batch == 2048);
    assert(params.n_ubatch == 1024);
    assert(params.n_batch_mixed == 512);
    assert(parse(params, {"check-args", "--mixed-batch-size", "1024"}));
    assert(params.n_batch_mixed == 1024);
    assert(parse(params, {"check-args", "--mixed-batch-size", "0"}));
    assert(params.n_batch_mixed == 0);
    assert(!parse(params, {"check-args", "--mixed-batch-size", "-1"}));
    assert(!parse(params, {"check-args", "--mixed-batch-size", "invalid"}));
    assert(!parse(params, {"check-args", "--mixed-batch-size", "2147483648"}));
    assert(setenv("LLAMA_ARG_MIXED_BATCH_SIZE", "512", 1) == 0);
    assert(parse(params, {"check-args"}));
    assert(params.n_batch_mixed == 512);
    assert(parse(params, {"check-args", "--mixed-batch-size", "1024"}));
    assert(params.n_batch_mixed == 1024);
    assert(setenv("LLAMA_ARG_MIXED_BATCH_SIZE", "-1", 1) == 0);
    assert(!parse(params, {"check-args"}));
    assert(unsetenv("LLAMA_ARG_MIXED_BATCH_SIZE") == 0);
    std::puts("PASS: mixed-batch default, integer CLI, unchanged batch sizes, rejection and environment checks");
}
