#include "ggml/src/ggml-cuda/fattn-tile.cuh"
#include "ggml/src/ggml-cuda/fattn.cuh"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static void cuda_check(cudaError_t status) {
    if (status != cudaSuccess) {
        std::fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(status));
        std::exit(3);
    }
}

static float sample_value(uint32_t & state, float amplitude) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return amplitude * (float(state & 0xffffu) / 32768.0f - 1.0f);
}

static ggml_tensor tensor_layout(ggml_type type, int64_t dim0, int64_t dim1, int64_t dim2,
                                size_t stride0, size_t stride1, size_t stride2, void * data) {
    ggml_tensor tensor{};
    tensor.type = type;
    tensor.ne[0] = dim0;
    tensor.ne[1] = dim1;
    tensor.ne[2] = dim2;
    tensor.ne[3] = 1;
    tensor.nb[0] = stride0;
    tensor.nb[1] = stride1;
    tensor.nb[2] = stride2;
    tensor.nb[3] = stride2 * dim2;
    tensor.data = data;
    return tensor;
}

static void launch_reference(ggml_backend_cuda_context & ctx, ggml_tensor & output, float scale) {
    const ggml_tensor & queries = *output.src[0];
    const ggml_tensor & keys = *output.src[1];
    const ggml_tensor & values = *output.src[2];
    const ggml_tensor & mask = *output.src[3];
    const dim3 block(32, 8);
    const dim3 grid((queries.ne[1] + 3) / 4, 1, 2);
    flash_attn_tile<256, 256, 4, 8, false, 0><<<grid, block, 0, ctx.stream()>>>(
        static_cast<const char *>(queries.data), static_cast<const char *>(keys.data),
        static_cast<const char *>(values.data), static_cast<const char *>(mask.data),
        nullptr, nullptr, static_cast<float *>(output.data), nullptr, scale, 0.0f, 0.0f, 0.0f, 0, 0.0f,
        256, init_fastdiv_values(queries.ne[1]), 16, 1, queries.nb[1], queries.nb[2], queries.nb[3],
        256, keys.ne[1], 2, 1, keys.nb[1], keys.nb[2], keys.nb[3],
        values.nb[1], values.nb[2], values.nb[3],
        mask.ne[1], 1, 1, mask.nb[1], mask.nb[2], mask.nb[3]);
    cuda_check(cudaGetLastError());
}

static void compare_cpu_double(
        const std::vector<float> & queries, const std::vector<half> & keys,
        const std::vector<half> & values, const std::vector<half> & mask,
        const std::vector<float> & baseline, const std::vector<float> & candidate,
        int query_count, int key_count, int query_row, size_t query_head,
        int key_row, size_t key_head, int value_row, size_t value_head, int mask_row, float scale) {
    const auto started = std::chrono::steady_clock::now();
    const int selections[][2] = {
        {0, 0}, {0, 7}, {1, 8}, {query_count / 4, 15},
        {query_count / 2, 3}, {query_count - 2, 8}, {query_count - 2, 15}, {query_count - 1, 9}
    };
    const int dimensions[] = {0, 1, 7, 15, 31, 63, 64, 95, 127, 128, 159, 191, 223, 240, 254, 255};
    std::vector<float> keys_float(size_t(key_count) * 2 * 256);
    for (int head = 0; head < 2; ++head) {
        for (int key = 0; key < key_count; ++key) {
            for (int dimension = 0; dimension < 256; ++dimension) {
                keys_float[(size_t(head) * key_count + key) * 256 + dimension] = __half2float(keys[head * key_head + key * key_row + dimension]);
            }
        }
    }
    std::vector<double> scores(key_count);
    double aggregate_squared_baseline = 0.0;
    double aggregate_squared_candidate = 0.0;
    double aggregate_max_baseline = 0.0;
    double aggregate_max_candidate = 0.0;
    size_t aggregate_elements = 0;
    size_t candidate_closer = 0;
    size_t baseline_closer = 0;
    for (const auto & selection : selections) {
        const int query = selection[0];
        const int head = selection[1];
        const int kv_head = head / 8;
        const float * query_data = queries.data() + head * query_head + query * query_row;
        double maximum = -INFINITY;
        size_t valid_keys = 0;
        for (int key = 0; key < key_count; ++key) {
            const double mask_value = __half2float(mask[size_t(query) * mask_row + key]);
            if (!std::isfinite(mask_value)) {
                scores[key] = -INFINITY;
                continue;
            }
            const float * key_data = keys_float.data() + (size_t(kv_head) * key_count + key) * 256;
            double dot = 0.0;
            for (int dimension = 0; dimension < 256; ++dimension) {
                dot += double(query_data[dimension]) * double(key_data[dimension]);
            }
            scores[key] = dot * double(scale) + mask_value;
            maximum = std::max(maximum, scores[key]);
            ++valid_keys;
        }
        double denominator = 0.0;
        if (valid_keys > 0) {
            for (int key = 0; key < key_count; ++key) {
                scores[key] = std::exp(scores[key] - maximum);
                denominator += scores[key];
            }
        }
        size_t baseline_nonfinite = 0;
        size_t candidate_nonfinite = 0;
        double maximum_baseline = 0.0;
        double maximum_candidate = 0.0;
        double squared_baseline = 0.0;
        double squared_candidate = 0.0;
        for (int dimension : dimensions) {
            double expected = 0.0;
            if (valid_keys > 0) {
                for (int key = 0; key < key_count; ++key) {
                    expected += scores[key] * double(__half2float(values[kv_head * value_head + key * value_row + dimension]));
                }
                expected /= denominator;
            }
            const size_t index = (size_t(query) * 16 + head) * 256 + dimension;
            const bool baseline_finite = std::isfinite(baseline[index]);
            const bool candidate_finite = std::isfinite(candidate[index]);
            baseline_nonfinite += !baseline_finite;
            candidate_nonfinite += !candidate_finite;
            const double baseline_error = baseline_finite ? std::abs(double(baseline[index]) - expected) : 0.0;
            const double candidate_error = candidate_finite ? std::abs(double(candidate[index]) - expected) : 0.0;
            maximum_baseline = std::max(maximum_baseline, baseline_error);
            maximum_candidate = std::max(maximum_candidate, candidate_error);
            squared_baseline += baseline_error * baseline_error;
            squared_candidate += candidate_error * candidate_error;
            if (valid_keys > 0 && baseline_finite && candidate_finite) {
                aggregate_squared_baseline += baseline_error * baseline_error;
                aggregate_squared_candidate += candidate_error * candidate_error;
                aggregate_max_baseline = std::max(aggregate_max_baseline, baseline_error);
                aggregate_max_candidate = std::max(aggregate_max_candidate, candidate_error);
                ++aggregate_elements;
                candidate_closer += candidate_error < baseline_error;
                baseline_closer += baseline_error < candidate_error;
            }
            std::printf("{\"kind\":\"double_sample\",\"query\":%d,\"head\":%d,\"dimension\":%d,\"all_masked\":%s,\"expected\":%.17g,\"baseline_finite\":%s,\"candidate_finite\":%s,\"baseline_absolute_error\":%.17g,\"candidate_absolute_error\":%.17g}\n",
                query, head, dimension, valid_keys == 0 ? "true" : "false", expected,
                baseline_finite ? "true" : "false", candidate_finite ? "true" : "false", baseline_error, candidate_error);
        }
        std::printf("{\"kind\":\"double_selection\",\"query\":%d,\"head\":%d,\"valid_keys\":%zu,\"dimensions\":16,\"baseline_nonfinite\":%zu,\"candidate_nonfinite\":%zu,\"baseline_max_absolute\":%.17g,\"candidate_max_absolute\":%.17g,\"baseline_rmse\":%.17g,\"candidate_rmse\":%.17g}\n",
            query, head, valid_keys, baseline_nonfinite, candidate_nonfinite, maximum_baseline, maximum_candidate,
            std::sqrt(squared_baseline / 16), std::sqrt(squared_candidate / 16));
    }
    const double milliseconds = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - started).count();
    std::printf("{\"kind\":\"double_summary\",\"selections\":8,\"normal_elements\":%zu,\"scale\":%.9g,\"baseline_max_absolute\":%.17g,\"candidate_max_absolute\":%.17g,\"baseline_rmse\":%.17g,\"candidate_rmse\":%.17g,\"candidate_closer\":%zu,\"baseline_closer\":%zu,\"cpu_double_ms\":%.6f}\n",
        aggregate_elements, scale, aggregate_max_baseline, aggregate_max_candidate,
        std::sqrt(aggregate_squared_baseline / aggregate_elements), std::sqrt(aggregate_squared_candidate / aggregate_elements),
        candidate_closer, baseline_closer, milliseconds);
    std::fflush(stdout);
}

int main(int argc, char ** argv) {
    const int query_count = argc > 1 ? std::atoi(argv[1]) : 1023;
    const int key_count = argc > 2 ? std::atoi(argv[2]) : 98048;
    const int rounds = argc > 3 ? std::atoi(argv[3]) : 1;
    if (argc > 5 || query_count < 64 || query_count > 1024 || key_count < 4096 || key_count > 98304 ||
        key_count % 256 || rounds < 0 || rounds > 3) {
        std::fprintf(stderr, "usage: integrated-attention-probe [queries:64..1024] [keys:4096..98304,multiple256] [rounds:0..3] [optional_output_f32_path]\n");
        return 2;
    }
    setenv("GGML_CUDA_FA_MAXWELL_GEMM", "1", 1);
    cudaDeviceProp device{};
    cuda_check(cudaGetDeviceProperties(&device, 0));
    if (device.major != 5 || device.minor != 2) {
        std::fprintf(stderr, "Probe restricted to SM52\n");
        return 2;
    }
    cuda_check(cudaSetDevice(0));
    const int query_row = 264;
    const size_t query_head = size_t(query_count + 3) * query_row;
    const int key_row = 264;
    const size_t key_head = size_t(key_count + 7) * key_row;
    const int value_row = 272;
    const size_t value_head = size_t(key_count + 9) * value_row;
    const int mask_row = key_count + 64;
    const int mask_queries = ((query_count + 15) / 16) * 16;
    const size_t output_elements = size_t(query_count) * 16 * 256;
    std::vector<float> host_queries(query_head * 16, -17.0f);
    std::vector<half> host_keys(key_head * 2, __float2half(-19.0f));
    std::vector<half> host_values(value_head * 2, __float2half(-23.0f));
    std::vector<half> host_mask(size_t(mask_queries) * mask_row, __float2half(-INFINITY));
    uint32_t random_state = 0x48271359u;
    for (int head = 0; head < 16; ++head) {
        for (int query = 0; query < query_count; ++query) {
            for (int dimension = 0; dimension < 256; ++dimension) {
                host_queries[head * query_head + query * query_row + dimension] = sample_value(random_state, 2.0f);
            }
        }
    }
    for (int head = 0; head < 2; ++head) {
        for (int key = 0; key < key_count; ++key) {
            for (int dimension = 0; dimension < 256; ++dimension) {
                host_keys[head * key_head + key * key_row + dimension] = __float2half(sample_value(random_state, 2.0f));
                host_values[head * value_head + key * value_row + dimension] = __float2half(sample_value(random_state, 1.0f));
            }
        }
    }
    for (int query = 0; query < query_count - 1; ++query) {
        const int last_key = key_count - query_count + query - 128;
        for (int key = 0; key <= last_key; ++key) {
            if (key % 97 != 5) {
                host_mask[size_t(query) * mask_row + key] = __float2half(-0.2f * (key % 7));
            }
        }
    }
    float * device_queries = nullptr;
    float * device_output = nullptr;
    half * device_keys = nullptr;
    half * device_values = nullptr;
    half * device_mask = nullptr;
    cuda_check(cudaMalloc(&device_queries, host_queries.size() * sizeof(float)));
    cuda_check(cudaMalloc(&device_output, (output_elements + 256) * sizeof(float)));
    cuda_check(cudaMalloc(&device_keys, host_keys.size() * sizeof(half)));
    cuda_check(cudaMalloc(&device_values, host_values.size() * sizeof(half)));
    cuda_check(cudaMalloc(&device_mask, host_mask.size() * sizeof(half)));
    cuda_check(cudaMemcpy(device_queries, host_queries.data(), host_queries.size() * sizeof(float), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_keys, host_keys.data(), host_keys.size() * sizeof(half), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_values, host_values.data(), host_values.size() * sizeof(half), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_mask, host_mask.data(), host_mask.size() * sizeof(half), cudaMemcpyHostToDevice));
    ggml_tensor queries = tensor_layout(GGML_TYPE_F32, 256, query_count, 16, 4, query_row * 4, query_head * 4, device_queries);
    ggml_tensor keys = tensor_layout(GGML_TYPE_F16, 256, key_count, 2, 2, key_row * 2, key_head * 2, device_keys);
    ggml_tensor values = tensor_layout(GGML_TYPE_F16, 256, key_count, 2, 2, value_row * 2, value_head * 2, device_values);
    ggml_tensor mask = tensor_layout(GGML_TYPE_F16, mask_row, mask_queries, 1, 2, mask_row * 2, size_t(mask_row) * mask_queries * 2, device_mask);
    ggml_tensor output = tensor_layout(GGML_TYPE_F32, 256, 16, query_count, 4, 256 * 4, 16 * 256 * 4, device_output);
    output.op = GGML_OP_FLASH_ATTN_EXT;
    output.src[0] = &queries;
    output.src[1] = &keys;
    output.src[2] = &values;
    output.src[3] = &mask;
    const float scale = 0.0625f;
    std::memcpy(output.op_params, &scale, sizeof(float));
    ggml_backend_cuda_context ctx(0);
    std::vector<float> reference(output_elements), result(output_elements + 256);
    launch_reference(ctx, output, scale);
    cuda_check(cudaStreamSynchronize(ctx.stream()));
    cuda_check(cudaMemcpy(reference.data(), device_output, output_elements * sizeof(float), cudaMemcpyDeviceToHost));
    cuda_check(cudaMemset(device_output, 0xa5, (output_elements + 256) * sizeof(float)));
    ggml_cuda_flash_attn_ext(ctx, &output);
    cuda_check(cudaStreamSynchronize(ctx.stream()));
    cuda_check(cudaMemcpy(result.data(), device_output, result.size() * sizeof(float), cudaMemcpyDeviceToHost));
    size_t nonfinite = 0;
    size_t all_masked_nonzero = 0;
    size_t guard_changed = 0;
    size_t different_bits = 0;
    double maximum_absolute = 0.0;
    double maximum_relative = 0.0;
    double squared_error = 0.0;
    const size_t normal_elements = output_elements - 16 * 256;
    for (size_t index = 0; index < normal_elements; ++index) {
        if (!std::isfinite(reference[index]) || !std::isfinite(result[index])) {
            ++nonfinite;
            continue;
        }
        different_bits += std::memcmp(&reference[index], &result[index], sizeof(float)) != 0;
        const double difference = std::abs(double(reference[index]) - result[index]);
        maximum_absolute = std::max(maximum_absolute, difference);
        maximum_relative = std::max(maximum_relative, difference / std::max(1e-5, std::abs(double(reference[index]))));
        squared_error += difference * difference;
    }
    for (size_t index = normal_elements; index < output_elements; ++index) {
        all_masked_nonzero += !std::isfinite(result[index]) || result[index] != 0.0f;
    }
    for (size_t index = output_elements; index < result.size(); ++index) {
        uint32_t bits;
        std::memcpy(&bits, &result[index], sizeof(bits));
        guard_changed += bits != 0xa5a5a5a5u;
    }
    const double rmse = std::sqrt(squared_error / normal_elements);
    std::printf("{\"kind\":\"integrated_correctness\",\"queries\":%d,\"keys\":%d,\"normal_elements\":%zu,\"different_bits\":%zu,\"nonfinite\":%zu,\"all_masked_nonzero\":%zu,\"output_guard_changed\":%zu,\"max_absolute\":%.12g,\"max_relative_floor1e5\":%.12g,\"rmse\":%.12g}\n",
        query_count, key_count, normal_elements, different_bits, nonfinite, all_masked_nonzero, guard_changed, maximum_absolute, maximum_relative, rmse);
    std::fflush(stdout);
    if (nonfinite || all_masked_nonzero || guard_changed || maximum_absolute > 1e-4 || rmse > 1e-5) {
        return 4;
    }
    compare_cpu_double(host_queries, host_keys, host_values, host_mask, reference, result,
        query_count, key_count, query_row, query_head, key_row, key_head, value_row, value_head, mask_row, scale);
    if (argc > 4) {
        FILE * dump = std::fopen(argv[4], "wb");
        if (!dump) {
            std::perror("output dump open");
            return 5;
        }
        const size_t written = std::fwrite(result.data(), sizeof(float), output_elements, dump);
        const int close_status = std::fclose(dump);
        if (written != output_elements || close_status != 0) {
            std::fprintf(stderr, "Output dump write failed\n");
            return 5;
        }
        std::printf("{\"kind\":\"output_dump\",\"elements\":%zu,\"bytes\":%zu,\"format\":\"native-f32\"}\n", output_elements, output_elements * sizeof(float));
        std::fflush(stdout);
    }
    cudaEvent_t start;
    cudaEvent_t stop;
    cuda_check(cudaEventCreate(&start));
    cuda_check(cudaEventCreate(&stop));
    const int order[] = {0, 1, 1, 0};
    for (int round = 0; round < rounds; ++round) {
        for (int position = 0; position < 4; ++position) {
            cuda_check(cudaEventRecord(start, ctx.stream()));
            if (order[position] == 0) {
                launch_reference(ctx, output, scale);
            } else {
                ggml_cuda_flash_attn_ext(ctx, &output);
            }
            cuda_check(cudaEventRecord(stop, ctx.stream()));
            cuda_check(cudaEventSynchronize(stop));
            float milliseconds = 0.0f;
            cuda_check(cudaEventElapsedTime(&milliseconds, start, stop));
            std::printf("{\"kind\":\"integrated_timing\",\"round\":%d,\"position\":%d,\"mode\":%d,\"milliseconds\":%.6f}\n", round, position, order[position], milliseconds);
            std::fflush(stdout);
        }
    }
    cuda_check(cudaEventDestroy(start));
    cuda_check(cudaEventDestroy(stop));
    cuda_check(cudaFree(device_queries));
    cuda_check(cudaFree(device_keys));
    cuda_check(cudaFree(device_values));
    cuda_check(cudaFree(device_mask));
    cuda_check(cudaFree(device_output));
    return 0;
}
