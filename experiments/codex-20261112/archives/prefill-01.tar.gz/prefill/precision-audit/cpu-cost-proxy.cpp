#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <vector>

int main() {
    const int key_count = 98048;
    const int query_count = 1023;
    const int queries[] = {0, 0, 1, query_count / 4, query_count / 2, query_count - 2, query_count - 2};
    const int dimensions[] = {0, 1, 7, 15, 31, 63, 64, 95, 127, 128, 159, 191, 223, 240, 254, 255};
    const auto started = std::chrono::steady_clock::now();
    std::vector<float> keys(size_t(key_count) * 2 * 256);
    std::vector<double> scores(key_count);
    float query[256];
    for (size_t index = 0; index < keys.size(); ++index) {
        keys[index] = float(int(index % 127) - 63) / 64.0f;
    }
    for (int dimension = 0; dimension < 256; ++dimension) {
        query[dimension] = float(dimension % 31) / 32.0f;
    }
    double checksum = 0.0;
    size_t terms = 0;
    for (int query_index : queries) {
        const int last_key = key_count - query_count + query_index - 128;
        double maximum = -INFINITY;
        for (int key = 0; key < key_count; ++key) {
            if (key > last_key || key % 97 == 5) {
                scores[key] = -INFINITY;
                continue;
            }
            double dot = 0.0;
            for (int dimension = 0; dimension < 256; ++dimension) {
                dot += double(query[dimension]) * double(keys[size_t(key) * 256 + dimension]);
            }
            terms += 256;
            scores[key] = dot * 0.0625 - 0.2 * (key % 7);
            maximum = std::max(maximum, scores[key]);
        }
        double denominator = 0.0;
        for (int key = 0; key < key_count; ++key) {
            scores[key] = std::exp(scores[key] - maximum);
            denominator += scores[key];
        }
        for (int dimension : dimensions) {
            double expected = 0.0;
            for (int key = 0; key < key_count; ++key) {
                expected += scores[key] * double(keys[(size_t(key_count) + key) * 256 + dimension]);
            }
            checksum += expected / denominator;
        }
    }
    const double milliseconds = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - started).count();
    std::printf("{\"kind\":\"cpu_cost_proxy\",\"qk_double_terms\":%zu,\"normal_selections\":7,\"dimensions\":16,\"elapsed_ms\":%.6f,\"checksum\":%.17g}\n", terms, milliseconds, checksum);
}
