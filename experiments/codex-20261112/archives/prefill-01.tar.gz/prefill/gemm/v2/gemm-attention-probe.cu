#include "ggml/src/ggml-cuda/fattn-tile.cuh"
#include <cublas_v2.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static constexpr int query_heads = 16;
static constexpr int key_value_heads = 2;
static constexpr int grouped_heads = 8;
static constexpr int head_dimension = 256;

static void cuda_check(cudaError_t status) {
    if (status != cudaSuccess) {
        std::fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(status));
        std::exit(3);
    }
}

static void cublas_check(cublasStatus_t status) {
    if (status != CUBLAS_STATUS_SUCCESS) {
        std::fprintf(stderr, "cuBLAS status: %d\n", int(status));
        std::exit(5);
    }
}

static float sample_value(uint32_t & state, float amplitude) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return amplitude * (float(state & 0xffffu) / 32768.0f - 1.0f);
}

static void launch_reference(const float * queries, const half * keys, const half * values,
                             const half * mask, float * output, int query_count, int key_count) {
    const dim3 block(32, 8);
    const dim3 grid((query_count + 3) / 4, 1, key_value_heads);
    const uint3 fast_queries = init_fastdiv_values(query_count);
    const int query_stride = head_dimension * sizeof(float);
    const int query_head_stride = query_count * query_stride;
    const int key_stride = head_dimension * sizeof(half);
    const int key_head_stride = key_count * key_stride;
    const int mask_stride = key_count * sizeof(half);
    flash_attn_tile<256, 256, 4, 8, false, 0><<<grid, block>>>(
        reinterpret_cast<const char *>(queries), reinterpret_cast<const char *>(keys),
        reinterpret_cast<const char *>(values), reinterpret_cast<const char *>(mask),
        nullptr, nullptr, output, nullptr, 0.0625f, 0.0f, 0.0f, 0.0f, 0, 0.0f,
        head_dimension, fast_queries, query_heads, 1, query_stride, query_head_stride, query_heads * query_head_stride,
        head_dimension, key_count, key_value_heads, 1, key_stride, key_head_stride, int64_t(key_value_heads) * key_head_stride,
        key_stride, key_head_stride, int64_t(key_value_heads) * key_head_stride,
        query_count, 1, 1, mask_stride, query_count * mask_stride, int64_t(query_count) * mask_stride);
    cuda_check(cudaGetLastError());
}

static __global__ void convert_key_values(const half * keys, const half * values,
                                          float * keys_float, float * values_float, size_t element_count) {
    for (size_t index = size_t(blockIdx.x) * blockDim.x + threadIdx.x; index < element_count;
         index += size_t(blockDim.x) * gridDim.x) {
        keys_float[index] = __half2float(keys[index]);
        values_float[index] = __half2float(values[index]);
    }
}

static __global__ void pack_query_tiles(const float * input, float * packed, int query_count, int tile_queries) {
    const size_t element_count = size_t(query_count) * query_heads * head_dimension;
    for (size_t index = size_t(blockIdx.x) * blockDim.x + threadIdx.x; index < element_count;
         index += size_t(blockDim.x) * gridDim.x) {
        const int dimension = index % head_dimension;
        const size_t column_index = index / head_dimension;
        const int local_column = column_index % (grouped_heads * tile_queries);
        const int chunk = column_index / (grouped_heads * tile_queries);
        const int group = chunk % key_value_heads;
        const int query_start = (chunk / key_value_heads) * tile_queries;
        const int head = group * grouped_heads + local_column / tile_queries;
        const int query = query_start + local_column % tile_queries;
        packed[index] = input[(size_t(head) * query_count + query) * head_dimension + dimension];
    }
}

template<bool maximum>
static __device__ float gemm_block_reduce(float value) {
    for (int offset = 16; offset > 0; offset /= 2) {
        const float other = __shfl_down_sync(0xffffffffu, value, offset);
        value = maximum ? fmaxf(value, other) : value + other;
    }
    __shared__ float warp_values[8];
    const int lane = threadIdx.x % 32;
    const int warp = threadIdx.x / 32;
    if (lane == 0) {
        warp_values[warp] = value;
    }
    __syncthreads();
    value = threadIdx.x < 8 ? warp_values[threadIdx.x] : (maximum ? -FLT_MAX : 0.0f);
    if (warp == 0) {
        for (int offset = 16; offset > 0; offset /= 2) {
            const float other = __shfl_down_sync(0xffffffffu, value, offset);
            value = maximum ? fmaxf(value, other) : value + other;
        }
        if (lane == 0) {
            warp_values[0] = value;
        }
    }
    __syncthreads();
    return warp_values[0];
}

static __global__ void causal_softmax(float * scores, int key_count, int query_count,
                                      int query_start, int tile_queries) {
    const int local_query = blockIdx.x;
    const int local_head = blockIdx.y;
    const int last_key = key_count - query_count + query_start + local_query;
    float * column = scores + (size_t(local_head) * tile_queries + local_query) * key_count;
    float local_max = -FLT_MAX;
    for (int key_index = threadIdx.x; key_index <= last_key; key_index += blockDim.x) {
        local_max = fmaxf(local_max, column[key_index]);
    }
    const float maximum = gemm_block_reduce<true>(local_max);
    float local_sum = 0.0f;
    for (int key_index = threadIdx.x; key_index < key_count; key_index += blockDim.x) {
        const float value = key_index <= last_key ? __expf(column[key_index] - maximum) : 0.0f;
        column[key_index] = value;
        local_sum += value;
    }
    const float inverse_sum = 1.0f / gemm_block_reduce<false>(local_sum);
    for (int key_index = threadIdx.x; key_index < key_count; key_index += blockDim.x) {
        column[key_index] *= inverse_sum;
    }
}

static __global__ void reduce_split_products(const float * partials, float * output,
                                             int query_start, int head_start, int tile_queries, int split_count) {
    const int index = blockIdx.x * blockDim.x + threadIdx.x;
    const int element_count = grouped_heads * tile_queries * head_dimension;
    if (index >= element_count) {
        return;
    }
    const int dimension = index % head_dimension;
    const int local_query = (index / head_dimension) % tile_queries;
    const int local_head = index / (head_dimension * tile_queries);
    float total = 0.0f;
    for (int split = 0; split < split_count; ++split) {
        total += partials[size_t(split) * grouped_heads * tile_queries * head_dimension + index];
    }
    output[((size_t(query_start) + local_query) * query_heads + head_start + local_head) * head_dimension + dimension] = total;
}

struct event_pair {
    cudaEvent_t start;
    cudaEvent_t stop;

    event_pair() {
        cuda_check(cudaEventCreate(&start));
        cuda_check(cudaEventCreate(&stop));
    }

    ~event_pair() {
        cudaEventDestroy(start);
        cudaEventDestroy(stop);
    }

    float milliseconds() const {
        float elapsed = 0.0f;
        cuda_check(cudaEventElapsedTime(&elapsed, start, stop));
        return elapsed;
    }
};

struct gemm_timing {
    float total = 0.0f;
    float conversion = 0.0f;
    float packing = 0.0f;
    float query_key = 0.0f;
    float softmax = 0.0f;
    float value_probability = 0.0f;
    float reduction = 0.0f;
};

struct gemm_attention {
    const float * query_input;
    int query_count;
    int key_count;
    int tile_queries;
    int split_keys;
    int split_count;
    int chunk_count;
    size_t key_elements;
    size_t query_elements;
    size_t score_elements;
    size_t partial_elements;
    size_t pointer_bytes;
    size_t scratch_bytes;
    float * keys_float = nullptr;
    float * values_float = nullptr;
    float * packed_queries = nullptr;
    float * scores = nullptr;
    float * partials = nullptr;
    void * workspace = nullptr;
    const float ** value_probability_left = nullptr;
    const float ** value_probability_right = nullptr;
    float ** value_probability_output = nullptr;
    cublasHandle_t handle;
    event_pair total_events;
    event_pair conversion_events;
    event_pair packing_events;
    std::vector<event_pair> stage_events;

    gemm_attention(const float * queries, int query_count_value, int key_count_value, int tile_queries_value, int split_keys_value) :
        query_input(queries), query_count(query_count_value), key_count(key_count_value), tile_queries(tile_queries_value), split_keys(split_keys_value),
        split_count(key_count / split_keys), chunk_count((query_count / tile_queries) * key_value_heads),
        key_elements(size_t(key_count) * key_value_heads * head_dimension),
        query_elements(size_t(query_count) * query_heads * head_dimension),
        score_elements(size_t(key_count) * grouped_heads * tile_queries),
        partial_elements(size_t(grouped_heads) * split_count * tile_queries * head_dimension),
        pointer_bytes(size_t(chunk_count) * split_count * sizeof(float *) * 3),
        scratch_bytes((key_elements * 2 + query_elements + score_elements + partial_elements) * sizeof(float) + pointer_bytes + (4u << 20)),
        stage_events(size_t(chunk_count) * 4) {
        if (scratch_bytes >= size_t(1) << 30) {
            std::fprintf(stderr, "Explicit scratch exceeds1GiB: %zu\n", scratch_bytes);
            std::exit(2);
        }
        cuda_check(cudaMalloc(&keys_float, key_elements * sizeof(float)));
        cuda_check(cudaMalloc(&values_float, key_elements * sizeof(float)));
        cuda_check(cudaMalloc(&packed_queries, query_elements * sizeof(float)));
        cuda_check(cudaMalloc(&scores, score_elements * sizeof(float)));
        cuda_check(cudaMalloc(&partials, partial_elements * sizeof(float)));
        cuda_check(cudaMalloc(&workspace, 4u << 20));
        const size_t value_probability_count = size_t(chunk_count) * split_count;
        cuda_check(cudaMalloc(&value_probability_left, value_probability_count * sizeof(float *)));
        cuda_check(cudaMalloc(&value_probability_right, value_probability_count * sizeof(float *)));
        cuda_check(cudaMalloc(&value_probability_output, value_probability_count * sizeof(float *)));
        std::vector<const float *> host_value_probability_left(value_probability_count), host_value_probability_right(value_probability_count);
        std::vector<float *> host_value_probability_output(value_probability_count);
        for (int chunk = 0; chunk < chunk_count; ++chunk) {
            const int group = chunk % key_value_heads;
            for (int split = 0; split < split_count; ++split) {
                const size_t value_probability_index = size_t(chunk) * split_count + split;
                host_value_probability_left[value_probability_index] = values_float + (size_t(group) * key_count + split * split_keys) * head_dimension;
                host_value_probability_right[value_probability_index] = scores + split * split_keys;
                host_value_probability_output[value_probability_index] = partials + size_t(split) * grouped_heads * tile_queries * head_dimension;
            }
        }
        cuda_check(cudaMemcpy(value_probability_left, host_value_probability_left.data(), value_probability_count * sizeof(float *), cudaMemcpyHostToDevice));
        cuda_check(cudaMemcpy(value_probability_right, host_value_probability_right.data(), value_probability_count * sizeof(float *), cudaMemcpyHostToDevice));
        cuda_check(cudaMemcpy(value_probability_output, host_value_probability_output.data(), value_probability_count * sizeof(float *), cudaMemcpyHostToDevice));
        cublas_check(cublasCreate(&handle));
        cublas_check(cublasSetStream(handle, nullptr));
        cublas_check(cublasSetPointerMode(handle, CUBLAS_POINTER_MODE_HOST));
        cublas_check(cublasSetMathMode(handle, CUBLAS_DEFAULT_MATH));
        cublas_check(cublasSetAtomicsMode(handle, CUBLAS_ATOMICS_NOT_ALLOWED));
        cublas_check(cublasSetWorkspace(handle, workspace, 4u << 20));
        int version = 0;
        cublas_check(cublasGetVersion(handle, &version));
        std::printf("{\"kind\":\"gemm_setup\",\"version\":2,\"cublas_version\":%d,\"tile_queries\":%d,\"packed_columns\":%d,\"split_keys\":%d,\"split_count\":%d,\"chunks\":%d,\"kv_float_bytes\":%zu,\"packed_query_bytes\":%zu,\"score_bytes\":%zu,\"partial_bytes\":%zu,\"pointer_bytes\":%zu,\"workspace_bytes\":4194304,\"scratch_bytes\":%zu}\n",
                    version, tile_queries, grouped_heads * tile_queries, split_keys, split_count, chunk_count, key_elements * sizeof(float) * 2, query_elements * sizeof(float),
                    score_elements * sizeof(float), partial_elements * sizeof(float), pointer_bytes, scratch_bytes);
    }

    ~gemm_attention() {
        cublasDestroy(handle);
        cudaFree(keys_float);
        cudaFree(values_float);
        cudaFree(packed_queries);
        cudaFree(scores);
        cudaFree(partials);
        cudaFree(workspace);
        cudaFree(value_probability_left);
        cudaFree(value_probability_right);
        cudaFree(value_probability_output);
    }

    gemm_timing run(const half * keys, const half * values, float * output) {
        const float query_key_scale = 0.0625f;
        const float one = 1.0f;
        const float zero = 0.0f;
        cuda_check(cudaEventRecord(total_events.start));
        cuda_check(cudaEventRecord(conversion_events.start));
        const unsigned int conversion_blocks = std::min<size_t>((key_elements + 255) / 256, 65535);
        convert_key_values<<<conversion_blocks, 256>>>(keys, values, keys_float, values_float, key_elements);
        cuda_check(cudaGetLastError());
        cuda_check(cudaEventRecord(conversion_events.stop));
        cuda_check(cudaEventRecord(packing_events.start));
        const unsigned int packing_blocks = std::min<size_t>((query_elements + 255) / 256, 65535);
        pack_query_tiles<<<packing_blocks, 256>>>(query_input, packed_queries, query_count, tile_queries);
        cuda_check(cudaGetLastError());
        cuda_check(cudaEventRecord(packing_events.stop));
        for (int chunk = 0; chunk < chunk_count; ++chunk) {
            const int group = chunk % key_value_heads;
            const int query_start = (chunk / key_value_heads) * tile_queries;
            const size_t value_probability_offset = size_t(chunk) * split_count;
            event_pair * events = stage_events.data() + size_t(chunk) * 4;
            cuda_check(cudaEventRecord(events[0].start));
            cublas_check(cublasSgemm(handle, CUBLAS_OP_T, CUBLAS_OP_N,
                key_count, grouped_heads * tile_queries, head_dimension, &query_key_scale,
                keys_float + size_t(group) * key_count * head_dimension, head_dimension,
                packed_queries + size_t(chunk) * grouped_heads * tile_queries * head_dimension, head_dimension,
                &zero, scores, key_count));
            cuda_check(cudaEventRecord(events[0].stop));
            cuda_check(cudaEventRecord(events[1].start));
            causal_softmax<<<dim3(tile_queries, grouped_heads), 256>>>(scores, key_count, query_count, query_start, tile_queries);
            cuda_check(cudaGetLastError());
            cuda_check(cudaEventRecord(events[1].stop));
            cuda_check(cudaEventRecord(events[2].start));
            cublas_check(cublasSgemmBatched(handle, CUBLAS_OP_N, CUBLAS_OP_N,
                head_dimension, grouped_heads * tile_queries, split_keys, &one,
                value_probability_left + value_probability_offset, head_dimension,
                value_probability_right + value_probability_offset, key_count, &zero,
                value_probability_output + value_probability_offset, head_dimension, split_count));
            cuda_check(cudaEventRecord(events[2].stop));
            cuda_check(cudaEventRecord(events[3].start));
            const int output_elements = grouped_heads * tile_queries * head_dimension;
            reduce_split_products<<<(output_elements + 255) / 256, 256>>>(
                partials, output, query_start, group * grouped_heads, tile_queries, split_count);
            cuda_check(cudaGetLastError());
            cuda_check(cudaEventRecord(events[3].stop));
        }
        cuda_check(cudaEventRecord(total_events.stop));
        cuda_check(cudaEventSynchronize(total_events.stop));
        gemm_timing timing;
        timing.total = total_events.milliseconds();
        timing.conversion = conversion_events.milliseconds();
        timing.packing = packing_events.milliseconds();
        for (int chunk = 0; chunk < chunk_count; ++chunk) {
            const event_pair * events = stage_events.data() + size_t(chunk) * 4;
            timing.query_key += events[0].milliseconds();
            timing.softmax += events[1].milliseconds();
            timing.value_probability += events[2].milliseconds();
            timing.reduction += events[3].milliseconds();
        }
        return timing;
    }
};

int main(int argc, char ** argv) {
    const int query_count = argc > 1 ? std::atoi(argv[1]) : 1024;
    const int key_count = argc > 2 ? std::atoi(argv[2]) : 98304;
    const int rounds = argc > 3 ? std::atoi(argv[3]) : 2;
    const int tile_queries = argc > 4 ? std::atoi(argv[4]) : 64;
    const int split_keys = argc > 5 ? std::atoi(argv[5]) : 4096;
    const uint32_t seed = argc > 6 ? uint32_t(std::strtoul(argv[6], nullptr, 0)) : 0x12345678u;
    if (argc > 7 || query_count < 64 || query_count > 1024 || query_count % 64 != 0 ||
        key_count < 4096 || key_count > 131072 || key_count % 4096 != 0 ||
        rounds < 1 || rounds > 5 || (tile_queries != 32 && tile_queries != 64) ||
        (split_keys != 2048 && split_keys != 4096 && split_keys != 8192) ||
        key_count % split_keys != 0 || seed == 0) {
        std::fprintf(stderr, "usage: gemm-attention-probe [queries:64..1024,multiple64] [keys:4096..131072,multiple4096] [rounds:1..5] [tile_queries:32|64] [split_keys:2048|4096|8192] [nonzero_seed]\n");
        return 2;
    }
    cudaDeviceProp device{};
    cuda_check(cudaGetDeviceProperties(&device, 0));
    if (device.major != 5 || device.minor != 2) {
        std::fprintf(stderr, "Probe restricted to SM52; got SM%d%d\n", device.major, device.minor);
        return 2;
    }
    cuda_check(cudaSetDevice(0));
    const size_t query_elements = size_t(query_count) * query_heads * head_dimension;
    const size_t key_elements = size_t(key_count) * key_value_heads * head_dimension;
    const size_t mask_elements = size_t(query_count) * key_count;
    const size_t base_device_bytes = query_elements * sizeof(float) * 2 + key_elements * sizeof(half) * 2 + mask_elements * sizeof(half);
    std::printf("{\"kind\":\"shape\",\"query_count\":%d,\"key_count\":%d,\"query_heads\":16,\"kv_heads\":2,\"head_dim\":256,\"base_device_bytes\":%zu,\"rounds\":%d,\"seed\":%u}\n",
                query_count, key_count, base_device_bytes, rounds, seed);
    std::vector<float> host_queries(query_elements);
    std::vector<half> host_keys(key_elements), host_values(key_elements), host_mask(mask_elements);
    uint32_t random_state = seed;
    for (float & value : host_queries) {
        value = sample_value(random_state, 2.0f);
    }
    for (size_t index = 0; index < key_elements; ++index) {
        host_keys[index] = __float2half(sample_value(random_state, 2.0f));
        host_values[index] = __float2half(sample_value(random_state, 1.0f));
    }
    for (int query_index = 0; query_index < query_count; ++query_index) {
        const int last_key = key_count - query_count + query_index;
        for (int key_index = 0; key_index < key_count; ++key_index) {
            host_mask[size_t(query_index) * key_count + key_index] = __float2half(key_index <= last_key ? 0.0f : -INFINITY);
        }
    }
    float * device_queries = nullptr;
    float * device_output = nullptr;
    half * device_keys = nullptr;
    half * device_values = nullptr;
    half * device_mask = nullptr;
    cuda_check(cudaMalloc(&device_queries, query_elements * sizeof(float)));
    cuda_check(cudaMalloc(&device_output, query_elements * sizeof(float)));
    cuda_check(cudaMalloc(&device_keys, key_elements * sizeof(half)));
    cuda_check(cudaMalloc(&device_values, key_elements * sizeof(half)));
    cuda_check(cudaMalloc(&device_mask, mask_elements * sizeof(half)));
    cuda_check(cudaMemcpy(device_queries, host_queries.data(), query_elements * sizeof(float), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_keys, host_keys.data(), key_elements * sizeof(half), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_values, host_values.data(), key_elements * sizeof(half), cudaMemcpyHostToDevice));
    cuda_check(cudaMemcpy(device_mask, host_mask.data(), mask_elements * sizeof(half), cudaMemcpyHostToDevice));
    size_t memory_before = 0;
    size_t memory_total = 0;
    cuda_check(cudaMemGetInfo(&memory_before, &memory_total));
    gemm_attention candidate(device_queries, query_count, key_count, tile_queries, split_keys);
    std::vector<float> reference(query_elements), result(query_elements);
    launch_reference(device_queries, device_keys, device_values, device_mask, device_output, query_count, key_count);
    cuda_check(cudaMemcpy(reference.data(), device_output, query_elements * sizeof(float), cudaMemcpyDeviceToHost));
    const gemm_timing cold_timing = candidate.run(device_keys, device_values, device_output);
    cuda_check(cudaMemcpy(result.data(), device_output, query_elements * sizeof(float), cudaMemcpyDeviceToHost));
    size_t memory_after = 0;
    cuda_check(cudaMemGetInfo(&memory_after, &memory_total));
    std::printf("{\"kind\":\"memory\",\"explicit_scratch_bytes\":%zu,\"measured_free_memory_delta_bytes\":%zu,\"cold_candidate_ms\":%.6f}\n",
                candidate.scratch_bytes, memory_before >= memory_after ? memory_before - memory_after : 0, cold_timing.total);
    size_t nonfinite = 0;
    size_t different_bits = 0;
    double maximum_absolute = 0.0;
    double maximum_relative = 0.0;
    double squared_error = 0.0;
    for (size_t index = 0; index < query_elements; ++index) {
        if (!std::isfinite(reference[index]) || !std::isfinite(result[index])) {
            ++nonfinite;
            continue;
        }
        different_bits += std::memcmp(&reference[index], &result[index], sizeof(float)) != 0;
        const double difference = std::abs(double(reference[index]) - result[index]);
        maximum_absolute = std::max(maximum_absolute, difference);
        maximum_relative = std::max(maximum_relative, difference / std::max(1e-5, std::abs(double(reference[index]))));
        squared_error += difference * difference;
    }
    const double rmse = std::sqrt(squared_error / query_elements);
    std::printf("{\"kind\":\"correctness\",\"elements\":%zu,\"different_bits\":%zu,\"nonfinite\":%zu,\"max_absolute\":%.12g,\"max_relative_floor1e5\":%.12g,\"rmse\":%.12g}\n",
                query_elements, different_bits, nonfinite, maximum_absolute, maximum_relative, rmse);
    std::fflush(stdout);
    if (nonfinite != 0 || maximum_absolute > 1e-4 || rmse > 1e-5) {
        std::fprintf(stderr, "Numerical comparison exceeds probe safety threshold; no performance run.\n");
        return 4;
    }
    event_pair reference_events;
    const int order[] = {0, 1, 1, 0};
    for (int round = 0; round < rounds; ++round) {
        for (int position = 0; position < 4; ++position) {
            const int mode = order[position];
            if (mode == 0) {
                cuda_check(cudaEventRecord(reference_events.start));
                launch_reference(device_queries, device_keys, device_values, device_mask, device_output, query_count, key_count);
                cuda_check(cudaEventRecord(reference_events.stop));
                cuda_check(cudaEventSynchronize(reference_events.stop));
                std::printf("{\"kind\":\"timing\",\"round\":%d,\"position\":%d,\"mode\":0,\"milliseconds\":%.6f}\n",
                            round, position, reference_events.milliseconds());
            } else {
                const gemm_timing timing = candidate.run(device_keys, device_values, device_output);
                const float accounted = timing.conversion + timing.packing + timing.query_key + timing.softmax + timing.value_probability + timing.reduction;
                std::printf("{\"kind\":\"timing\",\"round\":%d,\"position\":%d,\"mode\":1,\"milliseconds\":%.6f,\"conversion_ms\":%.6f,\"packing_ms\":%.6f,\"qk_ms\":%.6f,\"softmax_ms\":%.6f,\"pv_ms\":%.6f,\"reduction_ms\":%.6f,\"other_ms\":%.6f}\n",
                            round, position, timing.total, timing.conversion, timing.packing, timing.query_key, timing.softmax,
                            timing.value_probability, timing.reduction, timing.total - accounted);
            }
            std::fflush(stdout);
        }
    }
    cuda_check(cudaFree(device_queries));
    cuda_check(cudaFree(device_output));
    cuda_check(cudaFree(device_keys));
    cuda_check(cudaFree(device_values));
    cuda_check(cudaFree(device_mask));
    return 0;
}
