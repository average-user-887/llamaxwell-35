#include <cuda_runtime.h>
#include <nvml.h>
#include <dlfcn.h>
#include <cuda_fp16.h>
#include <algorithm>
#include <array>
#include <cfloat>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <random>
#include <vector>

#define CK(expression) do { const auto error = (expression); if (error != cudaSuccess) { std::fprintf(stderr, "CUDA %s: %s\n", #expression, cudaGetErrorString(error)); std::exit(2); } } while (0)

#include "kernel.generated.cuh"

struct Q8Block {
    half scale;
    int8_t codes[32];
};
static_assert(sizeof(Q8Block) == 34, "Q8_0 layout must be 34 bytes");

struct HostData {
    int context;
    int streams;
    std::vector<float> queries;
    std::vector<half> keys, values;
    std::vector<Q8Block> keys_q8, values_q8;
    std::vector<half> mask;
};

struct DeviceData {
    float *queries, *output_f16, *output_q8, *partial_output;
    float2 *partial_ml;
    half *keys, *values, *mask;
    Q8Block *keys_q8, *values_q8;
    ofa_params params;
};

static void quantize(const std::vector<half> & input, std::vector<Q8Block> & output) {
    for (size_t block = 0; block < output.size(); ++block) {
        float maximum = 0.0f;
        for (int index = 0; index < 32; ++index) maximum = std::max(maximum, std::abs(__half2float(input[32*block + index])));
        const float scale = maximum/127.0f;
        const float inverse = scale == 0.0f ? 0.0f : 1.0f/scale;
        output[block].scale = __float2half(scale);
        for (int index = 0; index < 32; ++index) output[block].codes[index] = static_cast<int8_t>(std::round(__half2float(input[32*block + index])*inverse));
    }
}

static HostData make_data(int context, int streams, float query_scale, unsigned seed) {
    HostData host;
    host.context = context;
    host.streams = streams;
    host.queries.resize(size_t(streams)*16*256);
    host.keys.resize(size_t(streams)*2*context*256);
    host.values.resize(host.keys.size());
    host.keys_q8.resize(host.keys.size()/32);
    host.values_q8.resize(host.values.size()/32);
    host.mask.resize(size_t(streams)*context, __float2half(0.0f));
    std::mt19937 generator(seed);
    std::normal_distribution<float> normal(0.0f, 1.0f);
    for (auto & query : host.queries) query = normal(generator)*query_scale;
    for (auto & key : host.keys) key = __float2half(normal(generator));
    for (auto & value : host.values) value = __float2half(normal(generator));
    quantize(host.keys, host.keys_q8);
    quantize(host.values, host.values_q8);
    return host;
}

template <typename Value> static void allocate_copy(Value ** device, const std::vector<Value> & host) {
    CK(cudaMalloc(device, host.size()*sizeof(Value)));
    CK(cudaMemcpy(*device, host.data(), host.size()*sizeof(Value), cudaMemcpyHostToDevice));
}

static DeviceData make_device(const HostData & host, int splits) {
    DeviceData device{};
    allocate_copy(&device.queries, host.queries);
    allocate_copy(&device.keys, host.keys);
    allocate_copy(&device.values, host.values);
    allocate_copy(&device.keys_q8, host.keys_q8);
    allocate_copy(&device.values_q8, host.values_q8);
    allocate_copy(&device.mask, host.mask);
    CK(cudaMalloc(&device.output_f16, host.queries.size()*sizeof(float)));
    CK(cudaMalloc(&device.output_q8, host.queries.size()*sizeof(float)));
    CK(cudaMalloc(&device.partial_output, size_t(splits)*host.streams*2*8*256*sizeof(float)));
    CK(cudaMalloc(&device.partial_ml, size_t(splits)*host.streams*2*8*sizeof(float2)));
    device.params.Q = reinterpret_cast<char *>(device.queries);
    device.params.mask = reinterpret_cast<char *>(device.mask);
    device.params.part_o = device.partial_output;
    device.params.part_ml = device.partial_ml;
    device.params.n_kv = host.context;
    device.params.nsplit = splits;
    device.params.nkvh = 2;
    device.params.mask_ne1 = 1;
    device.params.mask_ne3 = host.streams;
    device.params.scale_log2 = 1.4426950408889634f/16.0f;
    device.params.nbq1 = 256*sizeof(float);
    device.params.nbq2 = 256*sizeof(float);
    device.params.nbq3 = 16*256*sizeof(float);
    device.params.nbm1 = size_t(host.context)*sizeof(half);
    device.params.nbm3 = size_t(host.context)*sizeof(half);
    return device;
}

static void launch(DeviceData & device, int format, int streams) {
    ofa_params params = device.params;
    const size_t row_bytes = format == 0 ? 256*sizeof(half) : 8*sizeof(Q8Block);
    params.K = format == 0 ? reinterpret_cast<char *>(device.keys) : reinterpret_cast<char *>(device.keys_q8);
    params.V = format == 0 ? reinterpret_cast<char *>(device.values) : reinterpret_cast<char *>(device.values_q8);
    params.nbk1 = params.nbv1 = row_bytes;
    params.nbk2 = params.nbv2 = size_t(params.n_kv)*row_bytes;
    params.nbk3 = params.nbv3 = 2*size_t(params.n_kv)*row_bytes;
    float * output = format == 0 ? device.output_f16 : device.output_q8;
    const dim3 grid(params.nsplit, 2, streams);
    if (format == 0) q8_decode_kernel<0><<<grid, 256>>>(params);
    else q8_decode_kernel<1><<<grid, 256>>>(params);
    ofa_combine_kernel<<<dim3(16, streams), 256>>>(device.partial_output, device.partial_ml,
        reinterpret_cast<char *>(output), params.nsplit, 2, 256*sizeof(float), 16*256*sizeof(float));
    CK(cudaGetLastError());
}

static double dequantized(const std::vector<Q8Block> & input, size_t index) {
    const auto & block = input[index/32];
    return double(__half2float(block.scale))*block.codes[index%32];
}

static double reference_error(const HostData & host, const std::vector<float> & output, bool quantized) {
    double maximum_error = 0.0;
    for (int stream = 0; stream < host.streams; ++stream) {
        for (int head : {0, 7, 8, 15}) {
            const size_t query_base = (size_t(stream)*16 + head)*256;
            const size_t cache_base = (size_t(stream)*2 + head/8)*host.context*256;
            std::vector<double> probabilities(host.context);
            double maximum = -DBL_MAX;
            for (int token = 0; token < host.context; ++token) {
                double logit = 0.0;
                for (int dimension = 0; dimension < 256; ++dimension) {
                    const size_t index = cache_base + size_t(token)*256 + dimension;
                    const double key = quantized ? dequantized(host.keys_q8, index) : __half2float(host.keys[index]);
                    logit += host.queries[query_base + dimension]*key;
                }
                probabilities[token] = logit/16.0;
                maximum = std::max(maximum, probabilities[token]);
            }
            double denominator = 0.0;
            for (auto & probability : probabilities) {
                probability = std::exp(probability - maximum);
                denominator += probability;
            }
            for (int dimension : {0, 1, 31, 32, 63, 127, 191, 255}) {
                double result = 0.0;
                for (int token = 0; token < host.context; ++token) {
                    const size_t index = cache_base + size_t(token)*256 + dimension;
                    const double value = quantized ? dequantized(host.values_q8, index) : __half2float(host.values[index]);
                    result += probabilities[token]*value;
                }
                result /= denominator;
                maximum_error = std::max(maximum_error, std::abs(result - output[query_base + dimension]));
            }
        }
    }
    return maximum_error;
}

static bool validate(const HostData & host, DeviceData & device) {
    std::vector<float> f16(host.queries.size()), q8(host.queries.size());
    CK(cudaMemcpy(f16.data(), device.output_f16, f16.size()*sizeof(float), cudaMemcpyDeviceToHost));
    CK(cudaMemcpy(q8.data(), device.output_q8, q8.size()*sizeof(float), cudaMemcpyDeviceToHost));
    bool finite = true;
    double maximum_error = 0.0, squared_error = 0.0, f16_squared = 0.0, q8_squared = 0.0, product = 0.0;
    for (size_t index = 0; index < f16.size(); ++index) {
        finite = finite && std::isfinite(f16[index]) && std::isfinite(q8[index]);
        const double difference = double(f16[index]) - q8[index];
        maximum_error = std::max(maximum_error, std::abs(difference));
        squared_error += difference*difference;
        f16_squared += double(f16[index])*f16[index];
        q8_squared += double(q8[index])*q8[index];
        product += double(f16[index])*q8[index];
    }
    const double cpu_f16 = reference_error(host, f16, false);
    const double cpu_q8 = reference_error(host, q8, true);
    const bool correct = finite && cpu_f16 <= 1.0e-4 && cpu_q8 <= 1.0e-4;
    std::printf("{\"type\":\"correctness\",\"finite\":%s,\"kernel_reference_pass\":%s,\"cpu_max_abs_f16\":%.9g,\"cpu_max_abs_q8\":%.9g,\"q8_vs_f16_max_abs\":%.9g,\"q8_vs_f16_rmse\":%.9g,\"q8_vs_f16_relative_l2\":%.9g,\"q8_vs_f16_cosine\":%.9g,\"reference_output_samples\":%d}\n",
        finite ? "true" : "false", correct ? "true" : "false", cpu_f16, cpu_q8, maximum_error,
        std::sqrt(squared_error/f16.size()), std::sqrt(squared_error/f16_squared),
        product/std::sqrt(f16_squared*q8_squared), host.streams*4*8);
    return correct;
}

static double timed_run(DeviceData & device, int format, int streams, int repetitions, cudaEvent_t begin, cudaEvent_t end) {
    CK(cudaEventRecord(begin));
    for (int repetition = 0; repetition < repetitions; ++repetition) launch(device, format, streams);
    CK(cudaEventRecord(end));
    CK(cudaEventSynchronize(end));
    float milliseconds = 0.0f;
    CK(cudaEventElapsedTime(&milliseconds, begin, end));
    return milliseconds/repetitions;
}

static int cpu_check() {
    static_assert(offsetof(Q8Block, codes) == 2, "Q8_0 codes must follow the half scale");
    HostData host = make_data(256, 1, 1.0f, 20261112);
    double maximum_error = 0.0;
    for (size_t block = 0; block < host.keys_q8.size(); ++block) {
        double maximum = 0.0;
        for (int index = 0; index < 32; ++index) maximum = std::max(maximum, std::abs(double(__half2float(host.keys[block*32 + index]))));
        const double unrounded_scale = maximum/127.0;
        const double stored_scale = __half2float(host.keys_q8[block].scale);
        const double tolerance = unrounded_scale/2 + 127*std::abs(stored_scale - unrounded_scale) + 1.0e-6;
        for (int index = 0; index < 32; ++index) {
            const size_t offset = block*32 + index;
            const double error = std::abs(dequantized(host.keys_q8, offset) - __half2float(host.keys[offset]));
            if (error > tolerance) return 4;
            maximum_error = std::max(maximum_error, error);
        }
    }
    std::vector<half> zeros(32, __float2half(0.0f));
    std::vector<Q8Block> zero_block(1);
    quantize(zeros, zero_block);
    if (__half2float(zero_block[0].scale) != 0.0f) return 4;
    for (const int8_t code : zero_block[0].codes) if (code != 0) return 4;
    std::printf("{\"type\":\"cpu_layout_quantizer_check\",\"pass\":true,\"block_bytes\":%zu,\"codes_offset\":%zu,\"elements_checked\":%zu,\"max_quantization_abs\":%.9g,\"gpu_access\":false}\n",
        sizeof(Q8Block), offsetof(Q8Block, codes), host.keys.size(), maximum_error);
    return 0;
}

class Telemetry {
    void * library = nullptr;
    nvmlDevice_t device = nullptr;
    bool initialized = false;
    decltype(&nvmlInit_v2) initialize = nullptr;
    decltype(&nvmlShutdown) shutdown = nullptr;
    decltype(&nvmlDeviceGetHandleByPciBusId_v2) handle = nullptr;
    decltype(&nvmlDeviceGetClockInfo) clock = nullptr;
    decltype(&nvmlDeviceGetTemperature) temperature = nullptr;
    decltype(&nvmlDeviceGetPowerUsage) power = nullptr;
    decltype(&nvmlDeviceGetUtilizationRates) utilization = nullptr;

    static void field(const char * name, nvmlReturn_t status, unsigned int value) {
        if (status == NVML_SUCCESS) std::printf(",\"%s\":%u", name, value);
        else std::printf(",\"%s\":null", name);
    }

public:
    Telemetry() {
        library = dlopen("libnvidia-ml.so.1", RTLD_NOW | RTLD_LOCAL);
        if (!library) return;
        initialize = reinterpret_cast<decltype(initialize)>(dlsym(library, "nvmlInit_v2"));
        shutdown = reinterpret_cast<decltype(shutdown)>(dlsym(library, "nvmlShutdown"));
        handle = reinterpret_cast<decltype(handle)>(dlsym(library, "nvmlDeviceGetHandleByPciBusId_v2"));
        clock = reinterpret_cast<decltype(clock)>(dlsym(library, "nvmlDeviceGetClockInfo"));
        temperature = reinterpret_cast<decltype(temperature)>(dlsym(library, "nvmlDeviceGetTemperature"));
        power = reinterpret_cast<decltype(power)>(dlsym(library, "nvmlDeviceGetPowerUsage"));
        utilization = reinterpret_cast<decltype(utilization)>(dlsym(library, "nvmlDeviceGetUtilizationRates"));
        if (!initialize || !shutdown || !handle || !clock || !temperature || !power || !utilization) return;
        initialized = initialize() == NVML_SUCCESS;
        if (!initialized) return;
        char pci_bus[32]{};
        if (cudaDeviceGetPCIBusId(pci_bus, sizeof(pci_bus), 0) != cudaSuccess) return;
        if (handle(pci_bus, &device) != NVML_SUCCESS) device = nullptr;
    }

    ~Telemetry() {
        if (initialized && shutdown) shutdown();
        if (library) dlclose(library);
    }

    void sample(int block, int position, const char * phase) {
        std::printf("{\"type\":\"telemetry\",\"block\":%d,\"position\":%d,\"phase\":\"%s\",\"available\":%s",
            block, position, phase, device ? "true" : "false");
        if (device) {
            unsigned int value = 0;
            nvmlReturn_t status = clock(device, NVML_CLOCK_SM, &value);
            field("sm_mhz", status, value);
            status = clock(device, NVML_CLOCK_MEM, &value);
            field("memory_mhz", status, value);
            status = temperature(device, NVML_TEMPERATURE_GPU, &value);
            field("temperature_c", status, value);
            status = power(device, &value);
            field("power_mw", status, value);
            nvmlUtilization_t usage{};
            status = utilization(device, &usage);
            field("gpu_utilization_sample_pct", status, usage.gpu);
            field("memory_utilization_sample_pct", status, usage.memory);
        }
        std::printf("}\n");
    }
};


int main(int argc, char ** argv) {
    if (argc == 2 && std::strcmp(argv[1], "--cpu-check") == 0) return cpu_check();
    const int context = argc > 1 ? std::atoi(argv[1]) : 16384;
    const int streams = argc > 2 ? std::atoi(argv[2]) : 1;
    const int blocks = argc > 3 ? std::atoi(argv[3]) : 5;
    const int repetitions = argc > 4 ? std::atoi(argv[4]) : 50;
    const float query_scale = argc > 5 ? std::atof(argv[5]) : 1.0f;
    const unsigned seed = argc > 6 ? std::strtoul(argv[6], nullptr, 10) : 20261112;
    const int forced_splits = argc > 7 ? std::atoi(argv[7]) : 0;
    if (context < 256 || context > 131072 || context%256 || streams < 1 || streams > 2 || blocks < 1 || blocks > 20 || repetitions < 1 || repetitions > 500 || query_scale <= 0 || query_scale > 8 || forced_splits < 0 || forced_splits > context/64) {
        std::fprintf(stderr, "usage: %s context[256..131072 divisible by256] streams[1..2] ABBA_blocks[1..20] repeats[1..500] query_scale[0..8] seed splits[0=auto]\n", argv[0]);
        return 3;
    }
    cudaDeviceProp properties{};
    CK(cudaGetDeviceProperties(&properties, 0));
    if (properties.major != 5 || properties.minor != 2 || !std::strstr(properties.name, "M6000")) {
        std::fprintf(stderr, "This experiment requires the owner-selected M6000 SM52 device, got %s SM%d%d\n", properties.name, properties.major, properties.minor);
        return 3;
    }
    Telemetry telemetry;
    size_t free_bytes = 0, total_bytes = 0;
    CK(cudaMemGetInfo(&free_bytes, &total_bytes));
    const size_t cache_elements = size_t(streams)*2*context*256;
    const size_t estimated_bytes = 2*cache_elements*sizeof(half) + 2*(cache_elements/32)*sizeof(Q8Block) + 16*1024*1024;
    if (free_bytes < estimated_bytes + 256*1024*1024) {
        std::fprintf(stderr, "Insufficient free VRAM for bounded microbench: free=%zu requested~=%zu reserve=268435456\n", free_bytes, estimated_bytes);
        return 3;
    }
    int f16_resident = 0, q8_resident = 0;
    CK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&f16_resident, q8_decode_kernel<0>, 256, 0));
    CK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&q8_resident, q8_decode_kernel<1>, 256, 0));
    const int splits = forced_splits ? forced_splits : std::max(1, std::min(context/64, (2*properties.multiProcessorCount + 2*streams - 1)/(2*streams)));
    cudaFuncAttributes f16_attributes{}, q8_attributes{};
    CK(cudaFuncGetAttributes(&f16_attributes, q8_decode_kernel<0>));
    CK(cudaFuncGetAttributes(&q8_attributes, q8_decode_kernel<1>));
    std::printf("{\"type\":\"configuration\",\"device\":\"%s\",\"sm\":52,\"multiprocessors\":%d,\"context\":%d,\"streams\":%d,\"splits\":%d,\"query_scale\":%.4f,\"seed\":%u,\"abba_blocks\":%d,\"repetitions\":%d,\"free_vram_bytes\":%zu,\"estimated_vram_bytes\":%zu,\"f16_kv_bytes\":%zu,\"q8_kv_bytes\":%zu,\"f16_resident_blocks\":%d,\"q8_resident_blocks\":%d,\"f16_registers\":%d,\"q8_registers\":%d,\"f16_shared_bytes\":%zu,\"q8_shared_bytes\":%zu}\n",
        properties.name, properties.multiProcessorCount, context, streams, splits, query_scale, seed, blocks, repetitions,
        free_bytes, estimated_bytes, 2*cache_elements*sizeof(half), 2*(cache_elements/32)*sizeof(Q8Block),
        f16_resident, q8_resident, f16_attributes.numRegs, q8_attributes.numRegs, f16_attributes.sharedSizeBytes, q8_attributes.sharedSizeBytes);
    std::fflush(stdout);
    HostData host = make_data(context, streams, query_scale, seed);
    DeviceData device = make_device(host, splits);
    for (int warmup = 0; warmup < 5; ++warmup) {
        launch(device, 0, streams);
        launch(device, 1, streams);
    }
    CK(cudaDeviceSynchronize());
    if (!validate(host, device)) return 4;
    std::fflush(stdout);
    cudaEvent_t begin, end;
    CK(cudaEventCreate(&begin));
    CK(cudaEventCreate(&end));
    double warmup_ms = 0.0;
    while (warmup_ms < 1000.0) {
        warmup_ms += 100*timed_run(device, 0, streams, 100, begin, end);
        warmup_ms += 100*timed_run(device, 1, streams, 100, begin, end);
    }
    std::printf("{\"type\":\"post_validation_warmup\",\"gpu_milliseconds\":%.6f,\"loader\":\"native_q8_packed32\"}\n", warmup_ms);
    telemetry.sample(-1, -1, "post_warmup");
    std::vector<double> f16_blocks, q8_blocks, speedups;
    for (int block = 0; block < blocks; ++block) {
        double f16_total = 0.0, q8_total = 0.0;
        for (int position = 0; position < 4; ++position) {
            const int format = (position == 1 || position == 2) ^ (block%2);
            telemetry.sample(block, position, "before");
            const double milliseconds = timed_run(device, format, streams, repetitions, begin, end);
            telemetry.sample(block, position, "after");
            if (format) q8_total += milliseconds;
            else f16_total += milliseconds;
            std::printf("{\"type\":\"timing\",\"block\":%d,\"position\":%d,\"format\":\"%s\",\"milliseconds\":%.9f}\n", block, position, format ? "q8_0" : "f16", milliseconds);
        }
        f16_blocks.push_back(f16_total/2);
        q8_blocks.push_back(q8_total/2);
        speedups.push_back(f16_total/q8_total);
        std::fflush(stdout);
    }
    const double f16_mean = std::accumulate(f16_blocks.begin(), f16_blocks.end(), 0.0)/blocks;
    const double q8_mean = std::accumulate(q8_blocks.begin(), q8_blocks.end(), 0.0)/blocks;
    const double speedup_mean = std::accumulate(speedups.begin(), speedups.end(), 0.0)/blocks;
    double variance = 0.0;
    for (const double speedup : speedups) variance += (speedup - speedup_mean)*(speedup - speedup_mean);
    const double standard_error = blocks > 1 ? std::sqrt(variance/(blocks*(blocks - 1))) : 0.0;
    std::printf("{\"type\":\"summary\",\"context\":%d,\"streams\":%d,\"f16_ms\":%.9f,\"q8_ms\":%.9f,\"ratio_of_means\":%.9f,\"mean_block_speedup\":%.9f,\"block_speedup_standard_error\":%.9f,\"abba_blocks\":%d,\"synthetic_kernel_only\":true}\n",
        context, streams, f16_mean, q8_mean, f16_mean/q8_mean, speedup_mean, standard_error, blocks);
    telemetry.sample(blocks, -1, "complete");
    CK(cudaEventDestroy(begin));
    CK(cudaEventDestroy(end));
    CK(cudaFree(device.queries));
    CK(cudaFree(device.keys));
    CK(cudaFree(device.values));
    CK(cudaFree(device.keys_q8));
    CK(cudaFree(device.values_q8));
    CK(cudaFree(device.mask));
    CK(cudaFree(device.output_f16));
    CK(cudaFree(device.output_q8));
    CK(cudaFree(device.partial_output));
    CK(cudaFree(device.partial_ml));
    return 0;
}
