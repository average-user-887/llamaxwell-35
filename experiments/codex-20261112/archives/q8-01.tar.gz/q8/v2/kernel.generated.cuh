#define OFA_D   256
#define OFA_G   8
#define OFA_NW  4
#define OFA_T   4
#define OFA_NT  (OFA_NW*32)

static __device__ __forceinline__ void ofa_cvt8(const uint4 w, float * f) {
    const half2 * h = (const half2 *) &w;
#pragma unroll
    for (int i = 0; i < 4; ++i) {
        const float2 t = __half22float2(h[i]);
        f[2*i + 0] = t.x;
        f[2*i + 1] = t.y;
    }
}


struct ofa_params {
    const char * Q; const char * K; const char * V; const char * mask;
    float  * part_o;
    float2 * part_ml;
    int n_kv, nsplit, nkvh, mask_ne1, mask_ne3;
    float scale_log2;
    size_t nbq1, nbq2, nbq3;
    size_t nbk1, nbk2, nbk3;
    size_t nbv1, nbv2, nbv3;
    size_t nbm1, nbm3;
};


template <int n, int x>
static __device__ __forceinline__ void ofa_rs_step_x(float * s, const int lane) {
    const bool up = lane & x;
#pragma unroll
    for (int i = 0; i < n; ++i) {
        const float send = up ? s[i] : s[i + n];
        const float keep = up ? s[i + n] : s[i];
        s[i] = keep + __shfl_xor_sync(0xFFFFFFFF, send, x, 32);
    }
}

#define OFA_HG 4



template <int Format> struct KvCodec;

template <> struct KvCodec<0> {
    using Packet = uint4;
    static __device__ __forceinline__ int offset(int lane) { return lane*16; }
    static __device__ __forceinline__ Packet load(const char * pointer, int lane) {
        return __ldg(reinterpret_cast<const uint4 *>(pointer));
    }
    static __device__ __forceinline__ void convert(Packet packed, float * output) {
        ofa_cvt8(packed, output);
    }
};


template <> struct KvCodec<1> {
    struct Packet { unsigned int codes[2]; unsigned short scale; };
    static __device__ __forceinline__ int offset(int lane) { return (lane/4)*34 + (lane%4)*8; }
    static __device__ __forceinline__ Packet load(const char * pointer, int lane) {
        Packet packed;
        packed.scale = __ldg(reinterpret_cast<const unsigned short *>(pointer - (lane%4)*8));
        const uintptr_t aligned_address = reinterpret_cast<uintptr_t>(pointer) & ~uintptr_t(3);
        const unsigned int * words = reinterpret_cast<const unsigned int *>(aligned_address);
        const unsigned int first = __ldg(words);
        const unsigned int second = __ldg(words + 1);
        const unsigned int third = __ldg(words + 2);
        const unsigned int shift = 16 + ((lane/4)%2)*16;
        packed.codes[0] = __funnelshift_rc(first, second, shift);
        packed.codes[1] = __funnelshift_rc(second, third, shift);
        return packed;
    }
    static __device__ __forceinline__ void convert(Packet packed, float * output) {
        const float scale = __half2float(__ushort_as_half(packed.scale));
#pragma unroll
        for (int index = 0; index < 8; ++index) {
            const unsigned int value = packed.codes[index/4] >> (8*(index%4));
            output[index] = scale*float(static_cast<signed char>(value & 255));
        }
    }
};

template <int Format>
__global__ void __launch_bounds__(2*OFA_NT, 2) q8_decode_kernel(const ofa_params p) {
    const int split = blockIdx.x;
    const int kvh   = blockIdx.y;
    const int i3    = blockIdx.z;
    const int wid   = threadIdx.x >> 5;
    const int warp  = wid & (OFA_NW - 1);
    const int hg    = wid / OFA_NW;
    const int lane  = threadIdx.x & 31;

    __shared__ __align__(16) float s_p[2*OFA_NW][OFA_T*OFA_HG];
    __shared__ __align__(16) float s_a[2*OFA_NW][OFA_HG];
    __shared__ float  s_o[OFA_NW][OFA_G][OFA_D];
    __shared__ float  s_m[OFA_NW][OFA_G];
    __shared__ float  s_l[OFA_NW][OFA_G];

    float q[OFA_HG][8];
#pragma unroll
    for (int h = 0; h < OFA_HG; ++h) {
        const float4 * qp = (const float4 *) (p.Q + i3*p.nbq3 + (size_t)(kvh*OFA_G + hg*OFA_HG + h)*p.nbq2) + 2*lane;
        const float4 a = qp[0], b = qp[1];
        q[h][0] = a.x*p.scale_log2; q[h][1] = a.y*p.scale_log2; q[h][2] = a.z*p.scale_log2; q[h][3] = a.w*p.scale_log2;
        q[h][4] = b.x*p.scale_log2; q[h][5] = b.y*p.scale_log2; q[h][6] = b.z*p.scale_log2; q[h][7] = b.w*p.scale_log2;
    }
    float o[OFA_HG][8];
#pragma unroll
    for (int h = 0; h < OFA_HG; ++h) {
#pragma unroll
        for (int i = 0; i < 8; ++i) o[h][i] = 0.0f;
    }

    const int   jl = lane >> 3;
    float m_run = -FLT_MAX/2.0f;
    float l_run = 0.0f;

    const char * Kb = p.K + i3*p.nbk3 + kvh*p.nbk2 + KvCodec<Format>::offset(lane);
    const char * Vb = p.V + i3*p.nbv3 + kvh*p.nbv2 + KvCodec<Format>::offset(lane);
    const half * Mb = (const half *) (p.mask + (i3 % p.mask_ne3)*p.nbm3);

    const int nunits = p.n_kv / OFA_T;
    const int u0 = (int) (((long long) split      * nunits) / p.nsplit);
    const int u1 = (int) (((long long)(split + 1) * nunits) / p.nsplit);

    const size_t nbk1 = p.nbk1, nbv1 = p.nbv1;
    const char * kp = Kb + (size_t)(u0 + warp)*OFA_T*nbk1;
    const char * vp = Vb + (size_t)(u0 + warp)*OFA_T*nbv1;
    const half * mp = Mb + (u0 + warp)*OFA_T + jl;
    const size_t kstep = (size_t) OFA_NW*OFA_T*nbk1;
    const size_t vstep = (size_t) OFA_NW*OFA_T*nbv1;
    for (int u = u0 + warp; u < u1; u += OFA_NW, kp += kstep, vp += vstep, mp += OFA_NW*OFA_T) {
        typename KvCodec<Format>::Packet kr[OFA_T], vr[OFA_T];
        {
            const char * r = kp;
#pragma unroll
            for (int j = 0; j < OFA_T; ++j, r += nbk1) kr[j] = KvCodec<Format>::load(r, lane);
        }
        {
            const char * r = vp;
#pragma unroll
            for (int j = 0; j < OFA_T; ++j, r += nbv1) vr[j] = KvCodec<Format>::load(r, lane);
        }
        const float mk = __half2float(*mp);

        float s[OFA_T*OFA_HG];
#pragma unroll
        for (int j = 0; j < OFA_T; ++j) {
            float k[8];
            KvCodec<Format>::convert(kr[j], k);
#pragma unroll
            for (int h = 0; h < OFA_HG; ++h) {
                float acc = q[h][0]*k[0];
#pragma unroll
                for (int i = 1; i < 8; ++i) acc = fmaf(q[h][i], k[i], acc);
                s[j*OFA_HG + h] = acc;
            }
        }

        ofa_rs_step_x<8, 16>(s, lane);
        ofa_rs_step_x<4,  8>(s, lane);
        ofa_rs_step_x<2,  4>(s, lane);
        ofa_rs_step_x<1,  2>(s, lane);
        s[0] = s[0] + __shfl_xor_sync(0xFFFFFFFF, s[0], 1, 32);
        const float sc = s[0] + mk*1.4426950408889634f;
        float gm = fmaxf(sc, __shfl_xor_sync(0xFFFFFFFF, sc, 8, 32));
        gm = fmaxf(gm, __shfl_xor_sync(0xFFFFFFFF, gm, 16, 32));
        const float m_new = fmaxf(m_run, gm);
        const float alpha = exp2f(m_run - m_new);
        const float pr    = exp2f(sc - m_new);
        m_run = m_new;
        l_run = l_run*alpha + pr;
        if (!(lane & 1)) s_p[wid][lane >> 1] = pr;
        if (lane < 2*OFA_HG && !(lane & 1)) s_a[wid][lane >> 1] = alpha;
        __syncwarp();
        float a[OFA_HG];
        {
            const float4 a0 = *(const float4 *) &s_a[wid][0];
            a[0] = a0.x; a[1] = a0.y; a[2] = a0.z; a[3] = a0.w;
        }
#pragma unroll
        for (int h = 0; h < OFA_HG; ++h) {
#pragma unroll
            for (int i = 0; i < 8; ++i) o[h][i] *= a[h];
        }
#pragma unroll
        for (int j = 0; j < OFA_T; ++j) {
            float v[8];
            KvCodec<Format>::convert(vr[j], v);
            const float4 p0 = *(const float4 *) &s_p[wid][j*OFA_HG];
            const float pj[4] = {p0.x, p0.y, p0.z, p0.w};
#pragma unroll
            for (int h = 0; h < OFA_HG; ++h) {
#pragma unroll
                for (int i = 0; i < 8; ++i) o[h][i] = fmaf(pj[h], v[i], o[h][i]);
            }
        }
        __syncwarp();
    }

    l_run += __shfl_xor_sync(0xFFFFFFFF, l_run, 8, 32);
    l_run += __shfl_xor_sync(0xFFFFFFFF, l_run, 16, 32);
    if (lane < 2*OFA_HG && !(lane & 1)) { s_m[warp][hg*OFA_HG + (lane >> 1)] = m_run; s_l[warp][hg*OFA_HG + (lane >> 1)] = l_run; }
#pragma unroll
    for (int h = 0; h < OFA_HG; ++h) {
        float4 * dp = (float4 *) &s_o[warp][hg*OFA_HG + h][8*lane];
        dp[0] = make_float4(o[h][0], o[h][1], o[h][2], o[h][3]);
        dp[1] = make_float4(o[h][4], o[h][5], o[h][6], o[h][7]);
    }
    __syncthreads();

    const int blk = (i3*p.nkvh + kvh)*p.nsplit + split;
    float * po = p.part_o + (size_t) blk*OFA_G*OFA_D;
    for (int idx = threadIdx.x; idx < OFA_G*OFA_D; idx += 2*OFA_NT) {
        const int h = idx / OFA_D, d = idx % OFA_D;
        float M = s_m[0][h];
#pragma unroll
        for (int w = 1; w < OFA_NW; ++w) M = fmaxf(M, s_m[w][h]);
        float acc = 0.0f;
#pragma unroll
        for (int w = 0; w < OFA_NW; ++w) acc += s_o[w][h][d]*exp2f(s_m[w][h] - M);
        po[idx] = acc;
        if (d == 0) {
            float L = 0.0f;
#pragma unroll
            for (int w = 0; w < OFA_NW; ++w) L += s_l[w][h]*exp2f(s_m[w][h] - M);
            p.part_ml[(size_t) blk*OFA_G + h] = make_float2(M, L);
        }
    }
}


__global__ void __launch_bounds__(OFA_D) ofa_combine_kernel(const float * __restrict__ part_o, const float2 * __restrict__ part_ml,
        char * __restrict__ dst, const int nsplit, const int nkvh, const size_t nbd1, const size_t nbd3) {
    const int qh = blockIdx.x, i3 = blockIdx.y, d = threadIdx.x;
    const int kvh = qh / OFA_G, h = qh % OFA_G;
    const int blk0 = (i3*nkvh + kvh)*nsplit;
    float M = -FLT_MAX;
    for (int s = 0; s < nsplit; ++s) M = fmaxf(M, part_ml[(size_t)(blk0 + s)*OFA_G + h].x);
    float L = 0.0f, acc = 0.0f;
    for (int s = 0; s < nsplit; ++s) {
        const float2 ml = part_ml[(size_t)(blk0 + s)*OFA_G + h];
        const float  w  = exp2f(ml.x - M);
        L   += ml.y*w;
        acc += part_o[((size_t)(blk0 + s)*OFA_G + h)*OFA_D + d]*w;
    }
    float * out = (float *) (dst + i3*nbd3 + qh*nbd1);
    out[d] = L > 0.0f ? acc/L : 0.0f;
}

