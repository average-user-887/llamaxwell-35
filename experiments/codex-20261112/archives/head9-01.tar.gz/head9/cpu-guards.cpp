#include "ggml/src/ggml-cuda/maxwell-head9.cuh"

#include <cassert>
#include <cstdio>
#include <initializer_list>

int main() {
    ggml_init_params params{1024*1024, nullptr, true};
    ggml_context * context = ggml_init(params);
    assert(context);
    ggml_tensor * weights = ggml_new_tensor_2d(context, GGML_TYPE_Q4_0, 2048, 248320);
    ggml_tensor * inputs = ggml_new_tensor_2d(context, GGML_TYPE_F32, 2048, 16);
    ggml_tensor * outputs = ggml_new_tensor_2d(context, GGML_TYPE_F32, 248320, 16);
    size_t checks = 0;
    for (int columns = 1; columns <= 17; ++columns) {
        inputs->ne[1] = outputs->ne[1] = columns;
        assert(ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs) == (columns >= 9 && columns <= 16));
        assert(!ggml_cuda_maxwell_head9_supported(false, 520, weights, inputs, outputs));
        checks += 2;
    }
    inputs->ne[1] = outputs->ne[1] = 9;
    for (int cc : {500, 530, 610, 750, 860}) {
        assert(!ggml_cuda_maxwell_head9_supported(true, cc, weights, inputs, outputs));
        ++checks;
    }
    inputs->nb[1] += 64;
    outputs->nb[1] += 128;
    assert(ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
    ++checks;
    ggml_tensor original_weights = *weights;
    ggml_tensor original_inputs = *inputs;
    ggml_tensor original_outputs = *outputs;
    for (ggml_tensor * tensor : {weights, inputs, outputs}) {
        ggml_tensor original = *tensor;
        tensor->ne[2] = 2;
        assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
        *tensor = original;
        tensor->ne[3] = 2;
        assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
        *tensor = original;
        tensor->type = GGML_TYPE_F16;
        assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
        *tensor = original;
        tensor->nb[0] += 1;
        assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
        *tensor = original;
        checks += 4;
    }
    weights->ne[1] -= 1;
    assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
    *weights = original_weights;
    inputs->ne[0] -= 1;
    assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
    *inputs = original_inputs;
    outputs->ne[1] -= 1;
    assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
    *outputs = original_outputs;
    inputs->nb[1] = 2048*sizeof(float) - 4;
    assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
    *inputs = original_inputs;
    outputs->nb[1] += 1;
    assert(!ggml_cuda_maxwell_head9_supported(true, 520, weights, inputs, outputs));
    checks += 5;
    std::printf("{\"kind\":\"cpu_guards\",\"checks\":%zu,\"pass\":true}\n", checks);
    ggml_free(context);
    return 0;
}
