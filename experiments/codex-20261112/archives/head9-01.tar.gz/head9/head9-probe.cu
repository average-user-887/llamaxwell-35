#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-backend.h"
#include "ggml-cuda.h"

#include <cuda_runtime.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static void require(bool valid, const char * message) {
    if (!valid) {
        std::fprintf(stderr, "%s\n", message);
        std::exit(2);
    }
}

static float sample(uint32_t & state) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return float(state & 0xffffu)/32768.0f - 1.0f;
}

static double compute(ggml_backend_t backend, ggml_cgraph * graph) {
    const auto start = std::chrono::steady_clock::now();
    require(ggml_backend_graph_compute(backend, graph) == GGML_STATUS_SUCCESS, "graph compute failed");
    ggml_backend_synchronize(backend);
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
}

static bool run_case(ggml_backend_t backend, ggml_tensor * weights, int columns, bool padded) {
    constexpr int inner = 2048;
    constexpr int rows = 248320;
    const int input_stride = inner + (padded ? 16 : 0);
    const int output_stride = rows + (padded ? 32 : 0);
    ggml_init_params params{4*1024*1024, nullptr, true};
    ggml_context * context = ggml_init(params);
    require(context, "case context allocation failed");
    ggml_tensor * input_storage = ggml_new_tensor_2d(context, GGML_TYPE_F32, input_stride, columns);
    ggml_tensor * inputs = ggml_view_2d(context, input_storage, inner, columns, input_stride*sizeof(float), 0);
    ggml_tensor * output_storage = ggml_new_tensor_2d(context, GGML_TYPE_F32, output_stride, columns);
    ggml_tensor * result = ggml_view_2d(context, output_storage, rows, columns, output_stride*sizeof(float), 0);
    result->op = GGML_OP_MUL_MAT;
    result->src[0] = weights;
    result->src[1] = inputs;
    ggml_set_name(result, "head9_candidate");
    ggml_cgraph * candidate_graph = ggml_new_graph_custom(context, 32, false);
    ggml_build_forward_expand(candidate_graph, result);
    ggml_cgraph * reference_graph = ggml_new_graph_custom(context, 32, false);
    std::vector<ggml_tensor *> reference_parts;
    for (int column = 0; column < columns; column += 8) {
        const int count = std::min(8, columns - column);
        ggml_tensor * part_inputs = ggml_view_2d(context, input_storage, inner, count, input_stride*sizeof(float), column*input_stride*sizeof(float));
        ggml_tensor * part_outputs = ggml_mul_mat(context, weights, part_inputs);
        ggml_build_forward_expand(reference_graph, part_outputs);
        reference_parts.push_back(part_outputs);
    }
    ggml_backend_buffer_t buffer = ggml_backend_alloc_ctx_tensors(context, backend);
    require(buffer, "case buffer allocation failed");
    require(ggml_backend_supports_op(backend, result), "CUDA does not support candidate operation");
    std::vector<float> host_inputs(size_t(input_stride)*columns, -71.0f);
    std::vector<float> host_result(size_t(output_stride)*columns);
    std::vector<float> host_reference(size_t(rows)*columns);
    bool accepted = true;
    for (int repeat = 0; repeat < 4; ++repeat) {
        uint32_t random_state = 0xa5710639u + repeat*997u;
        for (int column = 0; column < columns; ++column) {
            for (int dimension = 0; dimension < inner; ++dimension) {
                host_inputs[size_t(column)*input_stride + dimension] = sample(random_state);
            }
        }
        ggml_backend_tensor_set(input_storage, host_inputs.data(), 0, host_inputs.size()*sizeof(float));
        ggml_backend_tensor_memset(output_storage, 0xa5, 0, ggml_nbytes(output_storage));
        const double reference_ms = compute(backend, reference_graph);
        size_t reference_offset = 0;
        for (ggml_tensor * part : reference_parts) {
            ggml_backend_tensor_get(part, host_reference.data() + reference_offset, 0, ggml_nbytes(part));
            reference_offset += ggml_nelements(part);
        }
        const double candidate_ms = compute(backend, candidate_graph);
        ggml_backend_tensor_get(output_storage, host_result.data(), 0, host_result.size()*sizeof(float));
        size_t nonfinite = 0;
        size_t different_bits = 0;
        size_t padding_changed = 0;
        double max_absolute = 0.0;
        double squared_error = 0.0;
        for (int column = 0; column < columns; ++column) {
            for (int row = 0; row < rows; ++row) {
                const float reference = host_reference[size_t(column)*rows + row];
                const float actual = host_result[size_t(column)*output_stride + row];
                nonfinite += !std::isfinite(reference) || !std::isfinite(actual);
                different_bits += std::memcmp(&reference, &actual, sizeof(float)) != 0;
                const double difference = double(reference) - actual;
                max_absolute = std::max(max_absolute, std::abs(difference));
                squared_error += difference*difference;
            }
            for (int row = rows; row < output_stride; ++row) {
                uint32_t bits;
                std::memcpy(&bits, &host_result[size_t(column)*output_stride + row], sizeof(bits));
                padding_changed += bits != 0xa5a5a5a5u;
            }
        }
        const double rmse = std::sqrt(squared_error/(size_t(rows)*columns));
        const bool passed = nonfinite == 0 && different_bits == 0 && padding_changed == 0;
        accepted = accepted && passed;
        std::printf("{\"kind\":\"head9_correctness\",\"columns\":%d,\"rows\":%d,\"padded\":%s,\"repeat\":%d,\"elements\":%zu,\"nonfinite\":%zu,\"different_bits\":%zu,\"padding_changed\":%zu,\"max_absolute\":%.12g,\"rmse\":%.12g,\"reference_ms\":%.6f,\"candidate_ms\":%.6f,\"pass\":%s}\n",
            columns, rows, padded ? "true" : "false", repeat, size_t(rows)*columns, nonfinite, different_bits,
            padding_changed, max_absolute, rmse, reference_ms, candidate_ms, passed ? "true" : "false");
        std::fflush(stdout);
    }
    ggml_backend_buffer_free(buffer);
    ggml_free(context);
    return accepted;
}

int main(int argc, char ** argv) {
    require(argc == 1, "head9-probe takes no arguments; runs full head at 9 and 16 columns");
    const char * flag = std::getenv("GGML_CUDA_MAXWELL_HEAD9_MMVQ");
    require(flag && std::strcmp(flag, "1") == 0, "Set GGML_CUDA_MAXWELL_HEAD9_MMVQ=1 before running");
    cudaDeviceProp device{};
    require(cudaGetDeviceProperties(&device, 0) == cudaSuccess, "CUDA device unavailable");
    require(device.major == 5 && device.minor == 2, "Probe restricted to SM52");
    ggml_backend_t backend = ggml_backend_cuda_init(0);
    require(backend, "CUDA backend initialization failed");
    ggml_init_params params{1024*1024, nullptr, true};
    ggml_context * context = ggml_init(params);
    require(context, "weight context allocation failed");
    ggml_tensor * weights = ggml_new_tensor_2d(context, GGML_TYPE_Q4_0, 2048, 248320);
    ggml_set_name(weights, "synthetic_output.weight");
    ggml_backend_buffer_t buffer = ggml_backend_alloc_ctx_tensors(context, backend);
    require(buffer, "weight buffer allocation failed");
    ggml_backend_buffer_set_usage(buffer, GGML_BACKEND_BUFFER_USAGE_WEIGHTS);
    constexpr int chunk_rows = 1024;
    std::vector<float> floating_weights(size_t(chunk_rows)*2048);
    std::vector<unsigned char> quantized_weights(ggml_row_size(GGML_TYPE_Q4_0, 2048)*chunk_rows);
    uint32_t random_state = 0x7129a3b1u;
    for (int row = 0; row < 248320; row += chunk_rows) {
        const int count = std::min(chunk_rows, 248320 - row);
        for (size_t index = 0; index < size_t(count)*2048; ++index) {
            floating_weights[index] = 0.125f*sample(random_state);
        }
        const size_t bytes = ggml_quantize_chunk(GGML_TYPE_Q4_0, floating_weights.data(), quantized_weights.data(), 0, count, 2048, nullptr);
        require(bytes == ggml_row_size(GGML_TYPE_Q4_0, 2048)*count, "unexpected quantization size");
        ggml_backend_tensor_set(weights, quantized_weights.data(), row*weights->nb[1], bytes);
    }
    size_t free_memory = 0;
    size_t total_memory = 0;
    require(cudaMemGetInfo(&free_memory, &total_memory) == cudaSuccess, "memory query failed");
    std::printf("{\"kind\":\"head9_setup\",\"device\":\"%s\",\"weight_bytes\":%zu,\"free_after_weight_upload\":%zu,\"q8_reuse\":\"%s\"}\n",
        device.name, ggml_nbytes(weights), free_memory, std::getenv("GGML_CUDA_Q8_REUSE") ? std::getenv("GGML_CUDA_Q8_REUSE") : "unset");
    std::fflush(stdout);
    bool accepted = true;
    for (int columns : {9, 16}) {
        accepted = run_case(backend, weights, columns, false) && accepted;
        accepted = run_case(backend, weights, columns, true) && accepted;
    }
    ggml_backend_buffer_free(buffer);
    ggml_free(context);
    ggml_backend_free(backend);
    ggml_quantize_free();
    return accepted ? 0 : 4;
}
